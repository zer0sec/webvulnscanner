<?php
/**
 * Vulnerability Scanner - Configuration
 * Use only on systems you are authorized to test.
 */

// Base URL of this scanner (for report links); works when called from api/ or root
$scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$scannerWebRoot = (strpos($scriptDir, '/api') !== false) ? dirname($scriptDir) : $scriptDir;
define('SCANNER_BASE_URL', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim($scannerWebRoot ?: '/', '/'));

// Timeouts (seconds). Use 0 for unlimited (long wordlists); ensure php.ini max_execution_time and Apache Timeout are raised.
define('HTTP_TIMEOUT', 10);
define('NMAP_TIMEOUT', 120);
define('SCAN_MAX_EXECUTION_TIME', 0);

// XSS scanner wordlist (URL or local path). Auto_Wordlists xss.txt
define('XSS_WORDLIST_URL', 'https://raw.githubusercontent.com/carlospolop/Auto_Wordlists/refs/heads/main/wordlists/xss.txt');
define('XSS_WORDLIST_PATH', __DIR__ . '/wordlists/xss.txt');
define('XSS_MAX_PAYLOADS', 500);

// Admin panel finder wordlist (same format as directory scan: one path per line)
define('ADMIN_WORDLIST_URL', 'https://raw.githubusercontent.com/hemaabokila/admin-panel-finder/refs/heads/main/wordlist/wordlist.txt');
define('ADMIN_WORDLIST_PATH', __DIR__ . '/wordlists/admin_panels.txt');
define('ADMIN_MAX_PATHS', 2000);

// NVD API (optional - get free key at https://nvd.nist.gov/developers/request-an-api-key for higher rate limits)
define('NVD_API_KEY', getenv('NVD_API_KEY') ?: '');

// Path to nmap (empty = use 'nmap' from PATH)
define('NMAP_PATH', 'C:\Program Files (x86)\Nmap\nmap.exe');

// Delay in milliseconds between each directory/admin scan request (lower = faster, higher WAF/ban risk)
define('SCAN_REQUEST_DELAY_MS', 150);

// SQL injection payload wordlist (error-based detection). HitmanAlharbi SQL-injections-simple
define('SQL_WORDLIST_URL', 'https://raw.githubusercontent.com/HitmanAlharbi/Wordlists/refs/heads/master/SQL-injections-simple');
define('SQL_WORDLIST_PATH', __DIR__ . '/wordlists/sql_injections.txt');
define('SQL_MAX_PAYLOADS', 500);

// Common paths for directory scanning (use a large wordlist; scan can run a long time)
define('DIR_SCAN_WORDLIST', __DIR__ . '/wordlists/dirs.txt');

// Report output directory (must be writable)
define('REPORTS_DIR', __DIR__ . '/reports');

// Allowed scan targets (empty = allow any; or set array of allowed hostnames)
define('ALLOWED_TARGETS', []);

// Scan profile: 'quick' (smaller wordlists, no subdomain) or 'full'
define('SCAN_PROFILE_DEFAULT', 'full');

// Optional webhook URL – POSTed with { target_url, ok, report_url, summary } when scan finishes
define('WEBHOOK_URL', getenv('SCAN_WEBHOOK_URL') ?: '');

// Paths to exclude from directory/admin scan (comma-separated or empty), e.g. "logout,api/health"
define('EXCLUDE_PATHS', getenv('SCAN_EXCLUDE_PATHS') ?: '');

// Rate limit: max scans per IP per hour (0 = no limit)
define('RATE_LIMIT_SCANS_PER_HOUR', 10);

// Scan history: keep last N scan records (target + timestamp) for display; 0 = disabled
define('SCAN_HISTORY_SIZE', 20);

// Optional auth for target (scan behind login). Empty = none. Or set: basic_user, basic_pass or leave empty
define('SCAN_AUTH_BASIC_USER', getenv('SCAN_AUTH_USER') ?: '');
define('SCAN_AUTH_BASIC_PASS', getenv('SCAN_AUTH_PASS') ?: '');
