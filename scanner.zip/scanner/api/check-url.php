<?php
/**
 * Check if a URL is reachable (ping / HEAD request).
 * POST or GET: target_url
 * Returns JSON: { "valid": true } or { "valid": false, "error": "..." }
 */
header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$url = trim($input['target_url'] ?? $_POST['target_url'] ?? $_GET['target_url'] ?? '');
if ($url === '') {
    echo json_encode(['valid' => false, 'error' => 'No URL provided']);
    exit;
}
if (!preg_match('#^https?://#i', $url)) {
    $url = 'http://' . $url;
}

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_NOBODY => true,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 3,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_USERAGENT => 'VulnScanner/1.0 (URL check)',
]);
curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

if ($err !== '') {
    echo json_encode(['valid' => false, 'error' => 'Could not reach website: ' . $err]);
    exit;
}
if ($code === 0) {
    echo json_encode(['valid' => false, 'error' => 'No response from website']);
    exit;
}
if ($code >= 200 && $code < 500) {
    echo json_encode(['valid' => true]);
    exit;
}
echo json_encode(['valid' => false, 'error' => 'Website returned HTTP ' . $code]);
exit;
