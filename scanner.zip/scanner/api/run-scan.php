<?php
/**
 * Run full vulnerability scan; streams progress as newline-delimited JSON with percent, then final result.
 * POST: target_url (required)
 * Response: one JSON object per line; type=progress (message, percent), type=result for final payload.
 */

ini_set('display_errors', '0');
error_reporting(E_ALL);
if (ob_get_level()) {
    ob_end_clean();
}

header('Content-Type: application/x-ndjson; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-cache');

function sendLine(array $data): void {
    echo json_encode($data) . "\n";
    flush();
}

function logLine(string $line): void {
    sendLine(['type' => 'log', 'line' => $line]);
}

try {
require_once dirname(__DIR__) . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendLine(['type' => 'result', 'ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$targetUrl = trim($input['target_url'] ?? $_POST['target_url'] ?? '');
$profile = trim($input['profile'] ?? $_POST['profile'] ?? (defined('SCAN_PROFILE_DEFAULT') ? SCAN_PROFILE_DEFAULT : 'full'));
$authUser = trim($input['auth_user'] ?? $_POST['auth_user'] ?? (defined('SCAN_AUTH_BASIC_USER') ? SCAN_AUTH_BASIC_USER : ''));
$authPass = trim($input['auth_pass'] ?? $_POST['auth_pass'] ?? (defined('SCAN_AUTH_BASIC_PASS') ? SCAN_AUTH_BASIC_PASS : ''));
$excludePaths = trim($input['exclude_paths'] ?? $_POST['exclude_paths'] ?? (defined('EXCLUDE_PATHS') ? EXCLUDE_PATHS : ''));
if ($targetUrl === '') {
    sendLine(['type' => 'result', 'ok' => false, 'error' => 'target_url is required']);
    exit;
}

if (!preg_match('#^https?://#i', $targetUrl)) {
    $targetUrl = 'http://' . $targetUrl;
}

$parsed = parse_url($targetUrl);
$host = $parsed['host'] ?? '';
if ($host === '') {
    sendLine(['type' => 'result', 'ok' => false, 'error' => 'Invalid URL']);
    exit;
}
$requesterIp = '';
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $requesterIp = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
} elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
    $requesterIp = trim($_SERVER['HTTP_X_REAL_IP']);
} elseif (!empty($_SERVER['REMOTE_ADDR'])) {
    $requesterIp = $_SERVER['REMOTE_ADDR'];
}
if (defined('ALLOWED_TARGETS') && is_array(ALLOWED_TARGETS) && count(ALLOWED_TARGETS) > 0 && !in_array(strtolower($host), array_map('strtolower', ALLOWED_TARGETS))) {
    sendLine(['type' => 'result', 'ok' => false, 'error' => 'Target not allowed']);
    exit;
}
$rateLimit = defined('RATE_LIMIT_SCANS_PER_HOUR') ? (int) RATE_LIMIT_SCANS_PER_HOUR : 0;
if ($rateLimit > 0 && $requesterIp !== '') {
    require_once dirname(__DIR__) . '/classes/RateLimiter.php';
    $limiter = new RateLimiter($rateLimit);
    if (!$limiter->isAllowed($requesterIp)) {
        sendLine(['type' => 'result', 'ok' => false, 'error' => 'Rate limit exceeded. Try again later.']);
        exit;
    }
}

$maxTime = defined('SCAN_MAX_EXECUTION_TIME') ? SCAN_MAX_EXECUTION_TIME : 0;
set_time_limit($maxTime > 0 ? $maxTime : 0);

require_once dirname(__DIR__) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/classes/DirectoryScanner.php';
require_once dirname(__DIR__) . '/classes/NmapScanner.php';
require_once dirname(__DIR__) . '/classes/SqlVulnScanner.php';
require_once dirname(__DIR__) . '/classes/CveLookup.php';
require_once dirname(__DIR__) . '/classes/ReportGenerator.php';
require_once dirname(__DIR__) . '/classes/SslChecker.php';
require_once dirname(__DIR__) . '/classes/WhoisLookup.php';
require_once dirname(__DIR__) . '/classes/XssScanner.php';
require_once dirname(__DIR__) . '/classes/SecurityHeadersChecker.php';
require_once dirname(__DIR__) . '/classes/TlsQualityChecker.php';
require_once dirname(__DIR__) . '/classes/TechnologyDetector.php';
require_once dirname(__DIR__) . '/classes/RobotsSitemapFetcher.php';
require_once dirname(__DIR__) . '/classes/SensitivePathsChecker.php';
require_once dirname(__DIR__) . '/classes/OpenRedirectScanner.php';
require_once dirname(__DIR__) . '/classes/SubdomainFinder.php';

$timeout = defined('HTTP_TIMEOUT') ? HTTP_TIMEOUT : 10;
$nmapTimeout = defined('NMAP_TIMEOUT') ? NMAP_TIMEOUT : 120;
$nmapPath = defined('NMAP_PATH') ? NMAP_PATH : '';
$wordlist = defined('DIR_SCAN_WORDLIST') ? DIR_SCAN_WORDLIST : (dirname(__DIR__) . '/wordlists/dirs.txt');
$scanDelayMs = defined('SCAN_REQUEST_DELAY_MS') ? (int) SCAN_REQUEST_DELAY_MS : 200;
$nvdKey = defined('NVD_API_KEY') ? NVD_API_KEY : '';
$xssWordlistUrl = defined('XSS_WORDLIST_URL') ? XSS_WORDLIST_URL : '';
$xssWordlistPath = defined('XSS_WORDLIST_PATH') ? XSS_WORDLIST_PATH : (dirname(__DIR__) . '/wordlists/xss.txt');
$xssMaxPayloads = defined('XSS_MAX_PAYLOADS') ? XSS_MAX_PAYLOADS : 500;

$results = [
    'requester_ip' => $requesterIp,
    'target_ip' => '',
    'whois' => '',
    'ssl' => null,
    'directory' => [],
    'admin_pages' => [],
    'nmap' => ['ports' => [], 'raw' => '', 'error' => null],
    'sql' => [],
    'xss' => [],
    'cve' => [],
    'security_headers' => null,
    'tls_quality' => null,
    'technologies' => [],
    'robots_sitemap' => null,
    'sensitive_paths' => [],
    'open_redirects' => [],
    'subdomains' => [],
    'profile' => $profile,
    'severity' => ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'info' => 0],
];

$percent = 0;
function progress(int $p, string $msg): void {
    global $percent;
    $percent = $p;
    sendLine(['type' => 'progress', 'percent' => $p, 'message' => $msg]);
}

// --- 1. WHOIS first (then target IP, SSL) ---
progress(2, 'Fetching WHOIS information...');
logLine("--- WHOIS ---");
$whois = new WhoisLookup($host, 15);
$whoisResult = $whois->run();
$results['whois'] = $whoisResult['raw'] ?? '';
if (!empty($whoisResult['error'])) {
    $results['whois'] = 'WHOIS error: ' . $whoisResult['error'];
    logLine($results['whois']);
} else {
    $whoisExcerpt = strlen($results['whois']) > 1500 ? substr($results['whois'], 0, 1500) . "\n[... truncated]" : $results['whois'];
    logLine($whoisExcerpt);
}
progress(5, 'WHOIS complete.');

$targetIp = gethostbyname($host);
$results['target_ip'] = $targetIp;
logLine("--- Target information ---\nTarget URL: " . $targetUrl . "\nResolved IP: " . $targetIp . "\nRequested by IP: " . ($requesterIp ?: 'N/A'));
progress(6, 'Target IP: ' . $targetIp);

$scheme = strtolower($parsed['scheme'] ?? 'http');
if ($scheme === 'https') {
    progress(7, 'Checking SSL certificate...');
    $sslChecker = new SslChecker($host, 443, $timeout);
    $results['ssl'] = $sslChecker->run();
    $ssl = $results['ssl'];
    $sslLog = "--- SSL / Certificate ---\nSubject: " . ($ssl['subject_full'] ?? $ssl['subject_cn'] ?? 'N/A') . "\nIssuer: " . ($ssl['issuer_full'] ?? $ssl['issuer_cn'] ?? 'N/A') . "\nValid from: " . ($ssl['valid_from'] ?? 'N/A') . "\nValid to: " . ($ssl['valid_to'] ?? 'N/A') . "\nVersion: " . ($ssl['version'] ?? 'N/A') . "\nSignature: " . ($ssl['signature_algorithm'] ?? 'N/A') . "\nSerial: " . ($ssl['serial_number'] ?? 'N/A');
    if (!empty($ssl['key_type'])) {
        $sslLog .= "\nPublic key: " . $ssl['key_type'] . (!empty($ssl['key_bits']) ? ' ' . $ssl['key_bits'] . ' bits' : '');
    }
    if (!empty($ssl['fingerprint_sha256'])) {
        $sslLog .= "\nFingerprint (SHA-256): " . $ssl['fingerprint_sha256'];
    }
    if (!empty($ssl['fingerprint_sha1'])) {
        $sslLog .= "\nFingerprint (SHA-1): " . $ssl['fingerprint_sha1'];
    }
    if (!empty($ssl['vulnerable'])) {
        $sslLog .= "\nVULNERABLE: " . ($ssl['vulnerable_reason'] ?? 'Certificate or protocol issue');
    } else {
        $sslLog .= "\nNo obvious certificate vulnerability detected.";
    }
    logLine($sslLog);
} else {
    $results['ssl'] = null;
    logLine("--- SSL ---\nTarget was HTTP; no SSL certificate checked.");
}
progress(8, 'Target info complete.');

// --- Security headers ---
progress(9, 'Checking security headers...');
logLine("\n--- Security headers ---");
$headersChecker = new SecurityHeadersChecker($targetUrl, $timeout);
$results['security_headers'] = $headersChecker->run();
foreach ($results['security_headers']['headers'] ?? [] as $name => $data) {
    $status = !empty($data['present']) ? 'OK' : 'MISSING';
    logLine("  " . $name . ": " . $status . ($data['value'] ? ' — ' . substr($data['value'], 0, 60) : ' — ' . ($data['recommendation'] ?? '')));
}

// --- TLS quality (HTTPS only) ---
if ($scheme === 'https') {
    logLine("\n--- TLS quality ---");
    $tlsChecker = new TlsQualityChecker($host, 443, $timeout);
    $results['tls_quality'] = $tlsChecker->run();
    logLine("  Protocol: " . ($results['tls_quality']['protocol'] ?? 'N/A') . " | Cipher: " . ($results['tls_quality']['cipher'] ?? 'N/A'));
    if (!empty($results['tls_quality']['issues'])) {
        foreach ($results['tls_quality']['issues'] as $iss) {
            logLine("  Issue: " . $iss);
        }
    }
} else {
    $results['tls_quality'] = null;
}

// --- Technology detection ---
progress(9, 'Detecting technologies...');
logLine("\n--- Technologies ---");
$techDetector = new TechnologyDetector($targetUrl, $timeout);
$results['technologies'] = $techDetector->run();
$tech = $results['technologies']['technologies'] ?? [];
if (empty($tech)) {
    logLine("  (none detected)");
} else {
    foreach ($tech as $k => $v) {
        logLine("  " . $k . ": " . (is_string($v) ? $v : json_encode($v)));
    }
}

// --- Robots.txt / sitemap ---
logLine("\n--- Robots.txt / Sitemap ---");
$robotsFetcher = new RobotsSitemapFetcher($targetUrl, $timeout);
$results['robots_sitemap'] = $robotsFetcher->run();
if (!empty($results['robots_sitemap']['robots_txt'])) {
    logLine("Robots.txt found. Sitemaps: " . count($results['robots_sitemap']['sitemap_urls'] ?? []) . ", Disallow paths: " . count($results['robots_sitemap']['disallow_paths'] ?? []));
} else {
    logLine("  No robots.txt or not accessible.");
}

// --- Sensitive paths ---
progress(9, 'Checking sensitive paths...');
logLine("\n--- Sensitive paths ---");
$sensitiveChecker = new SensitivePathsChecker($targetUrl, $timeout, $scanDelayMs);
$results['sensitive_paths'] = $sensitiveChecker->run();
logLine("Found " . count($results['sensitive_paths']) . " exposed path(s).");
foreach (array_slice($results['sensitive_paths'], 0, 15) as $sp) {
    logLine("  " . ($sp['url'] ?? '') . " [HTTP " . ($sp['status'] ?? '') . "]");
}

// --- Open redirect ---
logLine("\n--- Open redirect ---");
$redirectScanner = new OpenRedirectScanner($targetUrl, $timeout);
$results['open_redirects'] = $redirectScanner->run();
logLine("Found " . count($results['open_redirects']) . " potential open redirect(s).");
foreach (array_slice($results['open_redirects'], 0, 5) as $r) {
    logLine("  Param: " . ($r['param'] ?? '') . " — " . ($r['url'] ?? ''));
}

// --- 2. Nmap (stream live output to log) ---
progress(10, 'Running Nmap (scanning ports, detecting services)...');
logLine("\n--- Nmap (live) ---");
$nmapScanner = new NmapScanner($host, $nmapTimeout, $nmapPath);
$results['nmap'] = $nmapScanner->runWithOutput(function (string $line): void {
    logLine($line);
});
$portCount = count($results['nmap']['ports']);
if ($results['nmap']['error']) {
    logLine("Error: " . $results['nmap']['error']);
    progress(18, 'Nmap: ' . $results['nmap']['error']);
} else {
    logLine("--- Nmap summary: " . $portCount . " open port(s) ---");
    foreach ($results['nmap']['ports'] as $p) {
        $ver = trim($p['version'] ?? '');
        logLine("  Port " . ($p['port'] ?? '') . " | service: " . ($p['service'] ?? '') . " | version: " . ($ver !== '' ? $ver : '(none detected)'));
    }
    progress(18, 'Nmap complete. Found ' . $portCount . ' open port(s).');
}

// --- 3. XSS scanner ---
progress(20, 'Loading XSS wordlist and testing for reflected XSS...');
$xssScanner = new XssScanner($targetUrl, $timeout, $xssMaxPayloads);
$loaded = false;
if ($xssWordlistUrl && filter_var($xssWordlistUrl, FILTER_VALIDATE_URL)) {
    $loaded = $xssScanner->loadWordlist($xssWordlistUrl);
}
if (!$loaded && $xssWordlistPath && is_file($xssWordlistPath)) {
    $loaded = $xssScanner->loadWordlist($xssWordlistPath);
}
if ($loaded) {
    $xssProgress = function ($cur, $tot, $msg) {
        if ($tot <= 0) return;
        $p = 20 + (int)round(12 * $cur / $tot);
        sendLine(['type' => 'progress', 'percent' => min($p, 31), 'message' => $msg]);
    };
    $results['xss'] = $xssScanner->run($xssProgress);
} else {
    $results['xss'] = [];
}
$xssCount = count($results['xss']);
logLine("--- XSS findings ---\nFound " . $xssCount . " reflected XSS.");
foreach (array_slice($results['xss'], 0, 10) as $x) {
    logLine("  URL: " . ($x['url'] ?? '') . " | Payload: " . ($x['payload'] ?? ''));
}
if ($xssCount > 10) {
    logLine("  ... and " . ($xssCount - 10) . " more (see PDF report).");
}
progress(32, 'XSS check complete. Found ' . $xssCount . ' reflected XSS.');

// --- 4. SQL injection (error-based, wordlist payloads) ---
progress(34, 'Loading SQL injection wordlist and testing (error-verified)...');
$sqlWordlistUrl = defined('SQL_WORDLIST_URL') ? SQL_WORDLIST_URL : '';
$sqlWordlistPath = defined('SQL_WORDLIST_PATH') ? SQL_WORDLIST_PATH : (dirname(__DIR__) . '/wordlists/sql_injections.txt');
$sqlMaxPayloads = defined('SQL_MAX_PAYLOADS') ? (int) SQL_MAX_PAYLOADS : 500;
if ($profile === 'quick') {
    $sqlMaxPayloads = min($sqlMaxPayloads, 150);
}
$sqlScanner = new SqlVulnScanner($targetUrl, $timeout, $sqlMaxPayloads, $scanDelayMs);
$sqlLoaded = false;
if ($sqlWordlistUrl && filter_var($sqlWordlistUrl, FILTER_VALIDATE_URL)) {
    $sqlLoaded = $sqlScanner->loadWordlist($sqlWordlistUrl);
}
if (!$sqlLoaded && $sqlWordlistPath && is_file($sqlWordlistPath)) {
    $sqlLoaded = $sqlScanner->loadWordlist($sqlWordlistPath);
}
if ($sqlLoaded) {
    logLine("SQL wordlist loaded (" . $sqlMaxPayloads . " payloads).");
}
$sqlLastLoggedPct = 34;
$sqlProgressCallback = function ($pct, $msg) use (&$sqlLastLoggedPct) {
    progress($pct, $msg);
    if ($pct >= $sqlLastLoggedPct + 1 || $pct >= 42) {
        logLine('[' . $pct . '%] ' . $msg);
        $sqlLastLoggedPct = $pct;
    }
};
$results['sql'] = $sqlScanner->discoverAndTest($sqlProgressCallback);
$sqlCount = count($results['sql']);
logLine("--- SQL injection (error-verified) ---\nFound " . $sqlCount . " potential vulnerability(ies).");
foreach (array_slice($results['sql'], 0, 15) as $s) {
    logLine("  URL: " . ($s['url'] ?? '') . " | Payload: " . ($s['payload'] ?? '') . " | " . ($s['evidence'] ?? ''));
}
if ($sqlCount > 15) {
    logLine("  ... and " . ($sqlCount - 15) . " more (see PDF report).");
}
progress(42, 'SQL injection check complete. Found ' . $sqlCount . ' potential vuln(s).');

// --- 5. Admin panel finder ---
$adminWordlistUrl = defined('ADMIN_WORDLIST_URL') ? ADMIN_WORDLIST_URL : '';
$adminWordlistPath = defined('ADMIN_WORDLIST_PATH') ? ADMIN_WORDLIST_PATH : (dirname(__DIR__) . '/wordlists/admin_panels.txt');
$adminMaxPaths = defined('ADMIN_MAX_PATHS') ? (int) ADMIN_MAX_PATHS : 2000;
$adminLines = [];
if ($adminWordlistUrl && filter_var($adminWordlistUrl, FILTER_VALIDATE_URL)) {
    $ctx = stream_context_create(['http' => ['timeout' => 30]]);
    $content = @file_get_contents($adminWordlistUrl, false, $ctx);
    if ($content !== false) {
        $adminLines = array_filter(array_map('trim', explode("\n", $content)));
    }
}
if (empty($adminLines) && $adminWordlistPath && is_file($adminWordlistPath)) {
    $adminLines = array_filter(array_map('trim', file($adminWordlistPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)));
}
progress(44, 'Scanning for possible admin pages...');
logLine("\n--- Possible admin pages ---\nScanning wordlist...");
if (!empty($adminLines)) {
    $adminLines = array_slice(array_values($adminLines), 0, $adminMaxPaths);
    if ($profile === 'quick') {
        $adminLines = array_slice($adminLines, 0, 500);
    }
    $excludeList = array_filter(array_map('trim', explode(',', $excludePaths)));
    if (!empty($excludeList)) {
        $adminLines = array_filter($adminLines, function ($p) use ($excludeList) {
            foreach ($excludeList as $ex) {
                if ($ex !== '' && stripos($p, $ex) !== false) return false;
            }
            return true;
        });
    }
    $adminScanner = new DirectoryScanner($targetUrl, $timeout, $scanDelayMs);
    $adminScanner->setWordlist($adminLines);
    $totalAdmin = count($adminLines);
    $adminProgress = function ($current, $total) {
        if ($total <= 0) return;
        $p = 44 + (int) round(8 * $current / $total);
        sendLine(['type' => 'progress', 'percent' => min($p, 51), 'message' => 'Admin page finder... ' . $current . '/' . $total]);
    };
    $results['admin_pages'] = $adminScanner->run($totalAdmin > 0 ? $adminProgress : null);
} else {
    $results['admin_pages'] = [];
}
$adminCount = count($results['admin_pages']);
logLine("Found " . $adminCount . " possible admin page(s).");
foreach (array_slice($results['admin_pages'], 0, 20) as $f) {
    logLine("  " . ($f['url'] ?? '') . " [HTTP " . ($f['status'] ?? '') . "]");
}
if ($adminCount > 20) {
    logLine("  ... and " . ($adminCount - 20) . " more (see PDF report).");
}
progress(52, 'Admin page finder complete. Found ' . $adminCount . ' possible admin page(s).');

// --- 6. Directory scan ---
progress(54, 'Starting directory scan (this may take a while)...');
logLine("\n--- Directory / file discovery ---\nScanning wordlist...");
$dirScanner = new DirectoryScanner($targetUrl, $timeout, $scanDelayMs);
if (is_file($wordlist)) {
    $dirLines = array_values(array_filter(array_map('trim', file($wordlist, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))));
    if ($profile === 'quick') {
        $dirLines = array_slice($dirLines, 0, 500);
    }
    $excludeListDir = array_filter(array_map('trim', explode(',', $excludePaths)));
    if (!empty($excludeListDir)) {
        $dirLines = array_values(array_filter($dirLines, function ($p) use ($excludeListDir) {
            foreach ($excludeListDir as $ex) {
                if ($ex !== '' && stripos($p, $ex) !== false) return false;
            }
            return true;
        }));
    }
    $dirScanner->setWordlist($dirLines);
}
$totalDir = $dirScanner->getWordlistCount();
$dirProgress = function ($current, $total) {
    if ($total <= 0) return;
    $p = 54 + (int)round(35 * $current / $total);
    sendLine(['type' => 'progress', 'percent' => min($p, 88), 'message' => 'Directory / file scan... ' . $current . '/' . $total . ' (' . round(100 * $current / $total, 1) . '%)']);
};
$results['directory'] = $dirScanner->run($totalDir > 0 ? $dirProgress : null);
$dirCount = count($results['directory']);
logLine("Found " . $dirCount . " path(s).");
foreach (array_slice($results['directory'], 0, 30) as $f) {
    logLine("  " . ($f['url'] ?? '') . " [HTTP " . ($f['status'] ?? '') . "]");
}
if ($dirCount > 30) {
    logLine("  ... and " . ($dirCount - 30) . " more (see PDF report).");
}
progress(89, 'Directory scan complete. Found ' . $dirCount . ' path(s).');

// --- 7. CVE lookup (last) ---
progress(91, 'Looking up CVE vulnerabilities...');
logLine("\n--- CVE vulnerabilities ---");
$cveLookup = new CveLookup($nvdKey);
$keywords = ['Apache', 'nginx', 'MySQL', 'PHP', 'OpenSSL'];
foreach ($results['nmap']['ports'] as $p) {
    $svc = $p['service'] ?? '';
    $ver = $p['version'] ?? '';
    if ($svc !== '') $keywords[] = $svc;
    if ($ver !== '') $keywords[] = $svc . ' ' . explode(' ', $ver)[0];
}
$results['cve'] = [];
foreach (array_unique($keywords) as $kw) {
    $cves = $cveLookup->search($kw, 3);
    foreach ($cves as $c) {
        $results['cve'][$c['id']] = $c;
    }
}
$results['cve'] = array_values($results['cve']);
$cveCount = count($results['cve']);
logLine("Found " . $cveCount . " CVE(s).");
foreach (array_slice($results['cve'], 0, 8) as $c) {
    logLine("  " . ($c['id'] ?? '') . " | CVSS " . ($c['cvss_score'] ?? '') . " | " . ($c['severity'] ?? '') . " | " . substr($c['description'] ?? '', 0, 80) . "...");
}
if ($cveCount > 8) {
    logLine("  ... and " . ($cveCount - 8) . " more (see PDF report).");
}
progress(95, 'CVE lookup complete. Found ' . $cveCount . ' CVE(s).');

// --- Subdomains (full profile only) ---
$results['subdomains'] = [];
if ($profile === 'full') {
    logLine("\n--- Subdomains ---");
    $subFinder = new SubdomainFinder($host, $timeout, 20);
    $results['subdomains'] = $subFinder->run();
    logLine("Found " . count($results['subdomains']) . " subdomain(s).");
    foreach (array_slice($results['subdomains'], 0, 10) as $s) {
        logLine("  " . ($s['subdomain'] ?? '') . " → " . ($s['ip'] ?? ''));
    }
}
progress(96, 'All scans complete.');

// Severity counts for executive summary
$results['severity']['critical'] = count($results['sql']);
$results['severity']['high'] = count($results['xss']) + (!empty($results['ssl']['vulnerable']) ? 1 : 0) + (!empty($results['tls_quality']['weak']) ? 1 : 0);
$results['severity']['medium'] = count($results['open_redirects']) + min(1, count($results['sensitive_paths']));
$missingHeaders = 0;
foreach ($results['security_headers']['headers'] ?? [] as $h) {
    if (empty($h['present'])) $missingHeaders++;
}
$results['severity']['low'] = $missingHeaders;
$results['severity']['info'] = count($results['directory']) + count($results['admin_pages']) + count($results['nmap']['ports']);

// Detect "scan paused" (no useful data, likely blocked/firewall)
$noDirs = $dirCount === 0;
$noPorts = $portCount === 0;
$nmapError = !empty($results['nmap']['error']);
$likelyBlocked = $noDirs && $noPorts && ($nmapError || $targetIp === $host);

if ($likelyBlocked) {
    if (defined('SCAN_HISTORY_SIZE') && SCAN_HISTORY_SIZE > 0) {
        require_once dirname(__DIR__) . '/classes/ScanHistory.php';
        (new ScanHistory(SCAN_HISTORY_SIZE))->add($targetUrl, false, null);
    }
    sendLine([
        'type' => 'result',
        'ok' => false,
        'error' => 'Scan Paused. IP may be blocked or the website has firewall protection. Try again or allow the scanner IP.',
        'summary' => ['directory_count' => 0, 'admin_pages_count' => 0, 'ports_count' => 0, 'sql_vulns' => 0, 'cve_count' => 0, 'xss_count' => 0, 'severity' => $results['severity'] ?? []],
    ]);
    exit;
}

// 8. Generate PDF report (only after all scans complete)
logLine("\n--- Report ---\nGenerating PDF...");
progress(98, 'Generating PDF report...');
try {
    $reportGen = new ReportGenerator($targetUrl);
    $reportPath = $reportGen->generate($results);
    $reportUrl = SCANNER_BASE_URL . '/reports/' . basename($reportPath);
    progress(100, 'Report ready.');
    $reportFilename = basename($reportPath);
    if (defined('SCAN_HISTORY_SIZE') && SCAN_HISTORY_SIZE > 0) {
        require_once dirname(__DIR__) . '/classes/ScanHistory.php';
        (new ScanHistory(SCAN_HISTORY_SIZE))->add($targetUrl, true, $reportFilename);
    }
    if (defined('WEBHOOK_URL') && WEBHOOK_URL !== '') {
        $webhookPayload = [
            'target_url' => $targetUrl,
            'ok' => true,
            'report_url' => $reportUrl,
            'summary' => [
                'directory_count' => count($results['directory']),
                'admin_pages_count' => count($results['admin_pages']),
                'ports_count' => count($results['nmap']['ports']),
                'sql_vulns' => count($results['sql']),
                'cve_count' => count($results['cve']),
                'xss_count' => count($results['xss']),
                'severity' => $results['severity'],
            ],
        ];
        $ch = curl_init(WEBHOOK_URL);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($webhookPayload), CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => 5]);
        @curl_exec($ch);
        curl_close($ch);
    }
    sendLine([
        'type' => 'result',
        'ok' => true,
        'report_path' => $reportPath,
        'report_url' => $reportUrl,
        'report_filename' => $reportFilename,
        'summary' => [
            'directory_count' => count($results['directory']),
            'admin_pages_count' => count($results['admin_pages']),
            'ports_count' => count($results['nmap']['ports']),
            'sql_vulns' => count($results['sql']),
            'cve_count' => count($results['cve']),
            'xss_count' => count($results['xss']),
            'severity' => $results['severity'],
        ],
    ]);
} catch (Throwable $e) {
    if (defined('SCAN_HISTORY_SIZE') && SCAN_HISTORY_SIZE > 0) {
        require_once dirname(__DIR__) . '/classes/ScanHistory.php';
        (new ScanHistory(SCAN_HISTORY_SIZE))->add($targetUrl, false, null);
    }
    sendLine(['type' => 'result', 'ok' => false, 'error' => 'Report generation failed: ' . $e->getMessage()]);
}
} catch (Throwable $e) {
    if (defined('SCAN_HISTORY_SIZE') && SCAN_HISTORY_SIZE > 0 && !empty($targetUrl)) {
        require_once dirname(__DIR__) . '/classes/ScanHistory.php';
        (new ScanHistory(SCAN_HISTORY_SIZE))->add($targetUrl, false, null);
    }
    sendLine(['type' => 'result', 'ok' => false, 'error' => $e->getMessage()]);
}
