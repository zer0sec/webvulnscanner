<?php
/**
 * GET: returns last N scan history entries (url, at, ok, report) as JSON.
 */
header('Content-Type: application/json; charset=utf-8');

$maxSize = defined('SCAN_HISTORY_SIZE') ? (int) SCAN_HISTORY_SIZE : 20;
require_once dirname(__DIR__) . '/classes/ScanHistory.php';
$history = (new ScanHistory($maxSize))->getList();
echo json_encode(['history' => $history]);
