<?php
/**
 * Fetch and parse robots.txt and sitemap references.
 */

class RobotsSitemapFetcher
{
    private string $baseUrl;
    private int $timeout;

    public function __construct(string $baseUrl, int $timeout = 10)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
    }

    public function run(): array
    {
        $result = ['robots_txt' => '', 'robots_parsed' => [], 'sitemap_urls' => [], 'disallow_paths' => []];
        $robots = $this->fetch($this->baseUrl . '/robots.txt');
        $result['robots_txt'] = $robots;
        if ($robots !== '') {
            $lines = explode("\n", $robots);
            foreach ($lines as $line) {
                $line = trim($line);
                if (stripos($line, 'Sitemap:') === 0) {
                    $result['sitemap_urls'][] = trim(substr($line, 8));
                }
                if (stripos($line, 'Disallow:') === 0) {
                    $result['disallow_paths'][] = trim(substr($line, 9));
                }
            }
            $result['robots_parsed'] = array_filter(array_unique(array_merge($result['sitemap_urls'], $result['disallow_paths'])));
        }
        return $result;
    }

    private function fetch(string $url): string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body !== false && $code >= 200 && $code < 400) {
            return is_string($body) ? substr($body, 0, 8000) : '';
        }
        return '';
    }
}
