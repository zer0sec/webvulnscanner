<?php
/**
 * Test for open redirect (redirect, url, next, return, etc.) using a canary URL.
 */

class OpenRedirectScanner
{
    private string $baseUrl;
    private int $timeout;
    private string $canaryUrl = 'https://example.com/redirect-target';

    public function __construct(string $baseUrl, int $timeout = 10)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
    }

    public function run(): array
    {
        $params = ['redirect', 'url', 'next', 'return', 'returnUrl', 'redir', 'destination', 'dest', 'rurl', 'redirect_uri'];
        $found = [];
        foreach ($params as $param) {
            $testUrl = $this->baseUrl . (strpos($this->baseUrl, '?') !== false ? '&' : '?') . $param . '=' . urlencode($this->canaryUrl);
            $location = $this->getRedirectLocation($testUrl);
            if ($location !== null && stripos($location, 'example.com') !== false) {
                $found[] = ['param' => $param, 'url' => $testUrl, 'redirected_to' => $location];
            }
        }
        return $found;
    }

    private function getRedirectLocation(string $url): ?string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $location = curl_getinfo($ch, CURLINFO_REDIRECT_URL) ?: null;
        if ($location === null && $code >= 301 && $code <= 303) {
            $headers = curl_getinfo($ch, CURLINFO_HEADER_OUT);
            // We need the response Location header
        }
        curl_close($ch);
        // Retry with HEADER to get Location
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $output = curl_exec($ch);
        curl_close($ch);
        if (preg_match('/^Location:\s*(\S+)/mi', $output ?? '', $m)) {
            return trim($m[1]);
        }
        return null;
    }
}
