<?php
/**
 * Simple file-based rate limit: max N scans per IP per hour.
 */

class RateLimiter
{
    private string $storagePath;
    private int $maxPerHour;

    public function __construct(int $maxPerHour = 10)
    {
        $dir = defined('REPORTS_DIR') ? dirname(REPORTS_DIR) : __DIR__ . '/..';
        $this->storagePath = rtrim($dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'data';
        $this->maxPerHour = $maxPerHour;
    }

    public function isAllowed(string $ip): bool
    {
        if ($this->maxPerHour <= 0) {
            return true;
        }
        $file = $this->storagePath . '/rate_' . md5($ip) . '.json';
        if (!is_dir($this->storagePath)) {
            @mkdir($this->storagePath, 0755, true);
        }
        $now = time();
        $cutoff = $now - 3600;
        $timestamps = [];
        if (is_file($file)) {
            $data = @json_decode(file_get_contents($file), true);
            if (is_array($data) && isset($data['ts'])) {
                $timestamps = array_filter($data['ts'], function ($t) use ($cutoff) {
                    return $t > $cutoff;
                });
            }
        }
        if (count($timestamps) >= $this->maxPerHour) {
            return false;
        }
        $timestamps[] = $now;
        @file_put_contents($file, json_encode(['ts' => array_slice($timestamps, -100)]));
        return true;
    }
}
