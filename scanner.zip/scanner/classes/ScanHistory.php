<?php
/**
 * Store last N scans (target URL + timestamp) for display on frontend.
 */

class ScanHistory
{
    private string $storagePath;
    private int $maxSize;

    public function __construct(int $maxSize = 20)
    {
        $dir = defined('REPORTS_DIR') ? dirname(REPORTS_DIR) : __DIR__ . '/..';
        $this->storagePath = rtrim($dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'scan_history.json';
        $this->maxSize = max(0, $maxSize);
    }

    public function add(string $targetUrl, bool $ok, string $reportFilename = ''): void
    {
        if ($this->maxSize <= 0) {
            return;
        }
        $dir = dirname($this->storagePath);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $list = $this->getList();
        array_unshift($list, [
            'url' => $targetUrl,
            'at' => date('Y-m-d H:i:s'),
            'ok' => $ok,
            'report' => $reportFilename,
        ]);
        $list = array_slice($list, 0, $this->maxSize);
        @file_put_contents($this->storagePath, json_encode($list));
    }

    public function getList(): array
    {
        if (!is_file($this->storagePath)) {
            return [];
        }
        $data = @json_decode(file_get_contents($this->storagePath), true);
        return is_array($data) ? $data : [];
    }
}
