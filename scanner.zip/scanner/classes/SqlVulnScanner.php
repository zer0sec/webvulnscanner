<?php
/**
 * SQL injection scanner with error-based verification.
 * Uses a payload wordlist (e.g. HitmanAlharbi SQL-injections-simple) and only reports
 * when an SQL error message is detected in the response (OWASP error-based detection).
 */

class SqlVulnScanner
{
    private string $baseUrl;
    private int $timeout;
    private int $maxPayloads;
    private int $delayMs;
    private array $vulnerabilities = [];
    private array $errorPatterns = [];
    private array $payloads = [];

    public function __construct(string $baseUrl, int $timeout = 10, int $maxPayloads = 500, int $delayMs = 0)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
        $this->maxPayloads = max(1, $maxPayloads);
        $this->delayMs = max(0, $delayMs);
        $this->initErrorPatterns();
    }

    /**
     * Load payload wordlist from URL or local file. Returns true if loaded.
     */
    public function loadWordlist(string $urlOrPath): bool
    {
        $lines = [];
        if (preg_match('#^https?://#i', $urlOrPath)) {
            $ctx = stream_context_create(['http' => ['timeout' => 30]]);
            $content = @file_get_contents($urlOrPath, false, $ctx);
            if ($content === false) {
                return false;
            }
            $lines = preg_split('/\r?\n/', $content);
        } else {
            if (!is_readable($urlOrPath)) {
                return false;
            }
            $lines = file($urlOrPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        }
        $this->payloads = array_values(array_unique(array_filter(array_map('trim', $lines))));
        $this->payloads = array_slice($this->payloads, 0, $this->maxPayloads);
        return count($this->payloads) > 0;
    }

    private function initErrorPatterns(): void
    {
        $this->errorPatterns = [
            'mysql' => [
                "SQL syntax.*MySQL",
                "Warning.*mysql_",
                "MySqlException",
                "valid MySQL result",
                "MySqlClient\\.",
                "Syntax error or access violation",
                "mysql_fetch",
                "mysql_num_rows",
                "You have an error in your SQL syntax",
                "supplied argument is not a valid MySQL",
                "Unclosed quotation mark",
                "ODBC SQL",
            ],
            'mssql' => [
                "Microsoft SQL Native Client",
                "ODBC SQL Server Driver",
                "SQLServer JDBC Driver",
                "Unclosed quotation mark",
                "Microsoft OLE DB Provider for SQL Server",
                "\[SQL Server\]",
                "SqlException",
            ],
            'postgresql' => [
                "PostgreSQL.*ERROR",
                "Warning.*pg_",
                "valid PostgreSQL result",
                "Npgsql\\.",
            ],
            'oracle' => [
                "ORA-\\d{5}",
                "Oracle error",
                "Oracle.*Driver",
                "Warning.*oci_",
                "valid Oracle result",
            ],
            'generic' => [
                "SQL syntax",
                "Syntax error",
                "quoted string not properly terminated",
                "unclosed quotation",
            ],
        ];
    }

    /**
     * Test a single URL (e.g. page?id=1) with payloads; only report if response contains SQL error (error-based).
     * Optional $onProgress is called as (current, total) for each payload tried.
     */
    public function testUrl(string $urlWithParams, ?callable $onProgress = null): array
    {
        $this->vulnerabilities = [];
        $payloads = $this->getPayloads();
        $total = count($payloads);

        foreach ($payloads as $i => $payload) {
            if ($onProgress !== null) {
                $onProgress($i + 1, $total);
            }
            $testUrl = $this->injectPayload($urlWithParams, $payload);
            $response = $this->fetch($testUrl);
            if ($this->delayMs > 0) {
                usleep($this->delayMs * 1000);
            }
            if ($response === null) {
                continue;
            }
            $dbType = $this->detectSqlError($response);
            if ($dbType !== null) {
                $this->vulnerabilities[] = [
                    'url' => $testUrl,
                    'payload' => $payload,
                    'verified' => true,
                    'evidence' => 'SQL error detected in response',
                    'db_type' => $dbType,
                ];
                break; // One confirmed vuln per URL is enough
            }
        }
        return $this->vulnerabilities;
    }

    private function getPayloads(): array
    {
        if (count($this->payloads) > 0) {
            return $this->payloads;
        }
        return [
            "'", "\"", "`", "-- -", "#", "/*",
            "' OR '1'='1", "\" OR \"1\"=\"1", "' OR 1=1--", "1' ORDER BY 1--",
            "1 AND 1=1", "1 AND 1=2", "1' UNION SELECT NULL--",
        ];
    }

    /**
     * Discover query parameters from base URL and test them.
     * Optional $progressCallback(percent, message) is called to report progress (e.g. 34–42%).
     */
    public function discoverAndTest(?callable $progressCallback = null): array
    {
        $this->vulnerabilities = [];
        $url = $this->baseUrl;
        $separator = strpos($url, '?') !== false ? '&' : '?';
        $testUrls = [
            $url . $separator . 'id=1',
            $url . $separator . 'page=1',
            $url . $separator . 'cat=1',
            $url . $separator . 'user=1',
            $url . $separator . 'q=test',
            $url . $separator . 'search=1',
        ];
        $payloads = $this->getPayloads();
        $numPayloads = count($payloads);
        $numUrls = count($testUrls);
        $totalTests = $numUrls * max(1, $numPayloads);
        $done = 0;

        foreach ($testUrls as $testUrl) {
            $onProgress = null;
            if ($progressCallback !== null) {
                $onProgress = function ($current, $total) use (&$done, $totalTests, $progressCallback) {
                    $done++;
                    $pct = (int) round(34 + 8 * $done / $totalTests);
                    $progressCallback(min($pct, 42), 'SQL injection test ' . $done . '/' . $totalTests . ' (' . round(100 * $done / $totalTests, 1) . '%)');
                };
            }
            $found = $this->testUrl($testUrl, $onProgress);
            $this->vulnerabilities = array_merge($this->vulnerabilities, $found);
        }
        return $this->vulnerabilities;
    }

    private function injectPayload(string $url, string $payload): string
    {
        $enc = rawurlencode($payload);
        if (strpos($url, '=') !== false) {
            return preg_replace('/([?&][^=]+=)([^&]*)/', '${1}' . $enc, $url, 1);
        }
        return $url . (strpos($url, '?') !== false ? '&' : '?') . 'id=' . $enc;
    }

    private function fetch(string $url): ?string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $body = curl_exec($ch);
        curl_close($ch);
        return is_string($body) ? $body : null;
    }

    private function detectSqlError(string $response): ?string
    {
        $response = substr($response, 0, 50000);
        foreach ($this->errorPatterns as $dbType => $patterns) {
            foreach ($patterns as $pattern) {
                if (preg_match('/' . preg_quote($pattern, '/') . '/i', $response)
                    || @preg_match('/' . $pattern . '/i', $response)) {
                    return $dbType;
                }
            }
        }
        return null;
    }

    public function getVulnerabilities(): array
    {
        return $this->vulnerabilities;
    }
}
