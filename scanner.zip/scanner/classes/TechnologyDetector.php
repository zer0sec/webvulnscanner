<?php
/**
 * Detect technologies from HTTP headers and HTML (Server, X-Powered-By, meta generator, etc.).
 */

class TechnologyDetector
{
    private string $baseUrl;
    private int $timeout;

    public function __construct(string $baseUrl, int $timeout = 10)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
    }

    public function run(): array
    {
        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $body = curl_exec($ch);
        $headers = [];
        if (function_exists('curl_getinfo')) {
            $info = curl_getinfo($ch);
            if (!empty($info['request_header'])) {
                $headers = explode("\n", $info['request_header']);
            }
        }
        curl_close($ch);
        $headerLines = $this->getResponseHeaders($this->baseUrl);
        $tech = [];
        foreach ($headerLines as $line) {
            if (stripos($line, 'Server:') === 0) {
                $tech['Server'] = trim(substr($line, 7));
            }
            if (stripos($line, 'X-Powered-By:') === 0) {
                $tech['X-Powered-By'] = trim(substr($line, 14));
            }
            if (stripos($line, 'X-AspNet-Version:') === 0) {
                $tech['X-AspNet-Version'] = trim(substr($line, 18));
            }
            if (stripos($line, 'X-Generator:') === 0) {
                $tech['X-Generator'] = trim(substr($line, 12));
            }
            if (stripos($line, 'X-Drupal-Cache:') === 0) {
                $tech['CMS'] = 'Drupal';
            }
            if (stripos($line, 'X-Varnish:') === 0) {
                $tech['Cache'] = 'Varnish';
            }
            if (stripos($line, 'CF-Ray:') === 0 || stripos($line, 'cf-ray:') === 0) {
                $tech['CDN'] = 'Cloudflare';
            }
        }
        if ($body !== false && is_string($body)) {
            if (preg_match('/<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)["\']/i', $body, $m)) {
                $tech['Generator'] = $m[1];
            }
            if (preg_match('/wp-content\/|wp-includes\//i', $body)) {
                $tech['CMS'] = $tech['CMS'] ?? 'WordPress';
            }
            if (preg_match('/Joomla/i', $body)) {
                $tech['CMS'] = $tech['CMS'] ?? 'Joomla';
            }
            if (preg_match('/Drupal/i', $body)) {
                $tech['CMS'] = $tech['CMS'] ?? 'Drupal';
            }
            if (preg_match('/Laravel/i', $body)) {
                $tech['Framework'] = 'Laravel';
            }
            if (preg_match('/React|react\./i', $body)) {
                $tech['Frontend'] = 'React';
            }
            if (preg_match('/vue\.js|Vue\./i', $body)) {
                $tech['Frontend'] = $tech['Frontend'] ?? 'Vue.js';
            }
        }
        return ['technologies' => $tech];
    }

    private function getResponseHeaders(string $url): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $output = curl_exec($ch);
        curl_close($ch);
        if ($output === false) {
            return [];
        }
        $lines = explode("\n", $output);
        $out = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && strpos($line, 'HTTP/') !== 0) {
                $out[] = $line;
            }
        }
        return $out;
    }
}
