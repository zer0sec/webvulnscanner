<?php
/**
 * Check HTTP security headers (CSP, HSTS, X-Frame-Options, etc.).
 */

class SecurityHeadersChecker
{
    private string $baseUrl;
    private int $timeout;

    public function __construct(string $baseUrl, int $timeout = 10)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
    }

    public function run(): array
    {
        $headers = $this->fetchHeaders();
        $expected = [
            'Content-Security-Policy' => ['present' => false, 'value' => '', 'recommendation' => 'Prevents XSS and injection; add policy.'],
            'Strict-Transport-Security' => ['present' => false, 'value' => '', 'recommendation' => 'Enforce HTTPS; set max-age (e.g. 31536000).'],
            'X-Frame-Options' => ['present' => false, 'value' => '', 'recommendation' => 'Prevent clickjacking; use DENY or SAMEORIGIN.'],
            'X-Content-Type-Options' => ['present' => false, 'value' => '', 'recommendation' => 'Prevent MIME sniffing; use nosniff.'],
            'X-XSS-Protection' => ['present' => false, 'value' => '', 'recommendation' => 'Legacy; prefer CSP.'],
            'Referrer-Policy' => ['present' => false, 'value' => '', 'recommendation' => 'Control referrer; use strict-origin-when-cross-origin or no-referrer.'],
            'Permissions-Policy' => ['present' => false, 'value' => '', 'recommendation' => 'Restrict browser features (camera, geolocation, etc.).'],
        ];
        foreach (array_keys($expected) as $name) {
            foreach ($headers as $h) {
                if (stripos($h, $name . ':') === 0) {
                    $expected[$name]['present'] = true;
                    $expected[$name]['value'] = trim(substr($h, strlen($name) + 1));
                    break;
                }
            }
        }
        return ['headers' => $expected, 'raw' => $headers];
    }

    private function fetchHeaders(): array
    {
        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_HEADER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $output = curl_exec($ch);
        curl_close($ch);
        if ($output === false) {
            return [];
        }
        $lines = explode("\n", $output);
        $out = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && strpos($line, 'HTTP/') !== 0) {
                $out[] = $line;
            }
        }
        return $out;
    }
}
