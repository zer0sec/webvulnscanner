<?php
/**
 * CVE lookup via NVD API. Adds CVE IDs, descriptions, and fix information to the report.
 */

class CveLookup
{
    private string $apiKey;
    private int $timeout = 15;

    public function __construct(string $apiKey = '')
    {
        $this->apiKey = $apiKey;
    }

    /**
     * Search NVD for CVEs by keyword (e.g. product name, version).
     * Returns array of CVE entries with description and fix info.
     */
    public function search(string $keyword, int $maxResults = 10): array
    {
        $keyword = trim($keyword);
        if ($keyword === '') {
            return [];
        }
        $url = 'https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch=' . rawurlencode($keyword);
        if ($this->apiKey !== '') {
            $url .= '&apiKey=' . rawurlencode($this->apiKey);
        }
        $json = $this->fetch($url);
        if ($json === null) {
            return [];
        }
        $data = json_decode($json, true);
        if (!isset($data['vulnerabilities']) || !is_array($data['vulnerabilities'])) {
            return [];
        }
        $results = [];
        foreach (array_slice($data['vulnerabilities'], 0, $maxResults) as $item) {
            $cve = $item['cve'] ?? [];
            $id = $cve['id'] ?? '';
            $descriptions = $cve['descriptions'] ?? [];
            $desc = '';
            foreach ($descriptions as $d) {
                if (($d['lang'] ?? '') === 'en') {
                    $desc = $d['value'] ?? '';
                    break;
                }
            }
            if ($desc === '' && !empty($descriptions)) {
                $desc = $descriptions[0]['value'] ?? '';
            }
            $metrics = $cve['metrics'] ?? [];
            $cvssScore = '';
            $severity = '';
            if (!empty($metrics['cvssMetricV31'])) {
                $m = $metrics['cvssMetricV31'][0];
                $cvssScore = $m['cvssData']['baseScore'] ?? '';
                $severity = $m['cvssData']['baseSeverity'] ?? '';
            } elseif (!empty($metrics['cvssMetricV30'])) {
                $m = $metrics['cvssMetricV30'][0];
                $cvssScore = $m['cvssData']['baseScore'] ?? '';
                $severity = $m['cvssData']['baseSeverity'] ?? '';
            } elseif (!empty($metrics['cvssMetricV2'])) {
                $m = $metrics['cvssMetricV2'][0];
                $cvssScore = $m['cvssData']['baseScore'] ?? '';
                $severity = $m['cvssData']['severity'] ?? '';
            }
            $references = [];
            foreach ($cve['references'] ?? [] as $ref) {
                $references[] = $ref['url'] ?? '';
            }
            $results[] = [
                'id' => $id,
                'description' => $desc,
                'cvss_score' => $cvssScore,
                'severity' => $severity,
                'references' => array_slice($references, 0, 5),
                'fix' => $this->deriveFixAdvice($cve, $desc),
            ];
        }
        return $results;
    }

    /**
     * Derive fix/remediation advice from CVE data and description.
     */
    private function deriveFixAdvice(array $cve, string $description): string
    {
        $configurations = $cve['configurations'] ?? [];
        $fixAdvice = [];
        foreach ($configurations as $config) {
            foreach ($config['nodes'] ?? [] as $node) {
                foreach ($node['cpeMatch'] ?? [] as $match) {
                    $criteria = $match['criteria'] ?? '';
                    $versionEndExcluding = $match['versionEndExcluding'] ?? '';
                    $versionStartIncluding = $match['versionStartIncluding'] ?? '';
                    if ($versionEndExcluding !== '') {
                        $fixAdvice[] = "Upgrade to version {$versionEndExcluding} or later (if using affected product from criteria).";
                    }
                    if ($versionStartIncluding !== '' && empty($versionEndExcluding)) {
                        $fixAdvice[] = "Avoid using affected versions; upgrade to a patched release.";
                    }
                }
            }
        }
        if (!empty($fixAdvice)) {
            return implode(' ', array_unique($fixAdvice));
        }
        if (stripos($description, 'patch') !== false || stripos($description, 'update') !== false) {
            return "Apply the latest security patch or update from the vendor. Check CVE references for vendor advisory.";
        }
        return "Upgrade to the latest stable version. Monitor vendor security advisories and NVD references for patches.";
    }

    private function fetch(string $url): ?string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($code === 200 && is_string($body)) ? $body : null;
    }
}
