<?php
/**
 * Probe for sensitive paths (.env, .git, backup, phpinfo, config, etc.).
 */

class SensitivePathsChecker
{
    private string $baseUrl;
    private int $timeout;
    private int $delayMs;

    private static array $paths = [
        '.env', '.git/config', '.env.backup', '.env.local', 'backup.sql', 'phpinfo.php', 'info.php',
        'config.php', 'web.config', '.htaccess', 'composer.json', 'package.json', 'wp-config.php',
        'debug.log', '.DS_Store', 'thumbs.db', 'crossdomain.xml', 'clientaccesspolicy.xml',
    ];

    public function __construct(string $baseUrl, int $timeout = 10, int $delayMs = 0)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
        $this->delayMs = $delayMs;
    }

    public function run(): array
    {
        $found = [];
        foreach (self::$paths as $path) {
            $path = ltrim($path, '/');
            $url = $this->baseUrl . '/' . $path;
            $code = $this->probe($url);
            if ($code >= 200 && $code < 400) {
                $found[] = ['url' => $url, 'status' => $code];
            }
            if ($this->delayMs > 0) {
                usleep($this->delayMs * 1000);
            }
        }
        return $found;
    }

    private function probe(string $url): int
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $code;
    }
}
