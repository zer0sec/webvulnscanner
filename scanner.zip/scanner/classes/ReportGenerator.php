<?php
/**
 * PDF report generator for vulnerability scan results.
 * Uses TCPDF (composer: tecnickcom/tcpdf).
 */

require_once __DIR__ . '/../vendor/autoload.php';

use TCPDF;

class ReportGenerator
{
    private TCPDF $pdf;
    private string $targetUrl;
    private string $generatedAt;

    public function __construct(string $targetUrl)
    {
        $this->targetUrl = $targetUrl;
        $this->generatedAt = date('Y-m-d H:i:s');
        $this->pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
        $this->pdf->SetCreator('VulnScanner');
        $this->pdf->SetTitle('Vulnerability Scan Report - ' . $targetUrl);
        $this->pdf->SetMargins(15, 15, 15);
        $this->pdf->SetAutoPageBreak(true, 15);
        $this->pdf->SetFont('helvetica', '', 10);
    }

    public function generate(array $scanResults): string
    {
        $dir = defined('REPORTS_DIR') ? REPORTS_DIR : (__DIR__ . '/../reports');
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $filename = 'report_' . preg_replace('/[^a-zA-Z0-9.-]/', '_', parse_url($this->targetUrl, PHP_URL_HOST) ?: 'scan') . '_' . date('Y-m-d_His') . '.pdf';
        $filepath = rtrim($dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename;

        $this->addTitlePage($scanResults);
        $this->addTableOfContents($scanResults);
        $this->addExecutiveSummary($scanResults);
        $this->addTargetInfo($scanResults);
        $this->addSslSection($scanResults['ssl'] ?? null);
        $this->addSecurityHeadersSection($scanResults['security_headers'] ?? []);
        $this->addTlsQualitySection($scanResults['tls_quality'] ?? []);
        $this->addTechnologiesSection($scanResults['technologies'] ?? []);
        $this->addRobotsSitemapSection($scanResults['robots_sitemap'] ?? []);
        $this->addSensitivePathsSection($scanResults['sensitive_paths'] ?? []);
        $this->addOpenRedirectsSection($scanResults['open_redirects'] ?? []);
        $this->addSubdomainsSection($scanResults['subdomains'] ?? []);
        $this->addDirectoryFindings($scanResults['directory'] ?? []);
        $this->addAdminPagesSection($scanResults['admin_pages'] ?? []);
        $this->addNmapFindings($scanResults['nmap'] ?? []);
        $this->addSqlFindings($scanResults['sql'] ?? []);
        $this->addXssFindings($scanResults['xss'] ?? []);
        $this->addCveFindings($scanResults['cve'] ?? []);
        $this->addRemediationSummary($scanResults);

        $this->pdf->Output($filepath, 'F');
        return $filepath;
    }

    private function addTitlePage(array $scanResults): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 18);
        $this->pdf->Cell(0, 12, 'Vulnerability Scan Report', 0, 1, 'C');
        $this->pdf->SetFont('helvetica', '', 11);
        $this->pdf->Cell(0, 8, 'Target: ' . $this->targetUrl, 0, 1, 'C');
        $this->pdf->Cell(0, 6, 'Generated: ' . $this->generatedAt, 0, 1, 'C');
        $this->pdf->Ln(8);
        $this->pdf->SetFont('helvetica', '', 10);
        $this->pdf->MultiCell(0, 6, 'This report contains target info (IP, WHOIS), SSL certificate check, directory/file discovery, open ports and service versions (nmap), SQL injection (error-verified), XSS findings, CVE information, and remediation. Use only on systems you are authorized to test. Unauthorized scanning may be illegal. We are not responsible for how you use our product.', 0, 'L');
    }

    private function addTableOfContents(array $scanResults): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, 'Table of Contents', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        $toc = [
            '1. Executive Summary',
            '2. Target Information (IP & WHOIS)',
            '3. SSL / Certificate',
            '4. Security Headers',
            '5. TLS Quality',
            '6. Technologies Detected',
            '7. Robots.txt & Sitemap',
            '8. Sensitive Paths',
            '9. Open Redirects',
            '10. Subdomains',
            '11. Directory / File Discovery',
            '12. Possible admin pages',
            '13. Open Ports & Service Versions (Nmap)',
            '14. SQL Injection (Error-Verified)',
            '15. XSS Findings',
            '16. CVE Vulnerabilities & Fixes',
            '17. Remediation Summary',
        ];
        foreach ($toc as $line) {
            $this->pdf->Cell(0, 6, $line, 0, 1);
        }
    }

    private function addExecutiveSummary(array $scanResults): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '1. Executive Summary', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        $sev = $scanResults['severity'] ?? [];
        $c = (int)($sev['critical'] ?? 0);
        $h = (int)($sev['high'] ?? 0);
        $m = (int)($sev['medium'] ?? 0);
        $l = (int)($sev['low'] ?? 0);
        $this->pdf->Cell(0, 6, 'Severity counts: Critical ' . $c . ' | High ' . $h . ' | Medium ' . $m . ' | Low ' . $l . '.', 0, 1);
        $this->pdf->Ln(2);
        $risks = [];
        if ($c > 0) $risks[] = 'Critical: ' . $c . ' confirmed SQL injection finding(s). Immediate remediation required.';
        if ($h > 0) $risks[] = 'High: ' . $h . ' finding(s) (e.g. XSS, weak TLS/SSL). Address soon.';
        if ($m > 0) $risks[] = 'Medium: ' . $m . ' finding(s) (e.g. open redirects, exposed sensitive paths).';
        if ($l > 0) $risks[] = 'Low: ' . $l . ' missing or weak security header(s).';
        if (empty($risks)) $risks[] = 'No critical or high findings in this scan. Review medium/low and maintain good security hygiene.';
        foreach ($risks as $line) {
            $this->pdf->MultiCell(0, 6, $line, 0, 'L');
        }
    }

    private function addTargetInfo(array $scanResults): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '2. Target Information (IP & WHOIS)', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        $ip = $scanResults['target_ip'] ?? '';
        $requesterIp = $scanResults['requester_ip'] ?? '';
        $this->pdf->Cell(0, 6, 'Target URL: ' . $this->targetUrl, 0, 1);
        $this->pdf->Cell(0, 6, 'Resolved IP: ' . ($ip !== '' ? $ip : 'N/A'), 0, 1);
        $this->pdf->Cell(0, 6, 'Requested by IP address: ' . ($requesterIp !== '' ? $requesterIp : 'N/A'), 0, 1);
        $whois = $scanResults['whois'] ?? '';
        if ($whois !== '') {
            $this->pdf->Ln(2);
            $this->pdf->SetFont('helvetica', 'B', 10);
            $this->pdf->Cell(0, 6, 'WHOIS (excerpt):', 0, 1);
            $this->pdf->SetFont('helvetica', '', 8);
            $this->pdf->MultiCell(0, 5, strlen($whois) > 3000 ? substr($whois, 0, 3000) . "\n[... truncated]" : $whois, 0, 'L');
            $this->pdf->SetFont('helvetica', '', 10);
        }
    }

    private function addSslSection(?array $ssl): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '3. SSL / Certificate', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if ($ssl === null) {
            $this->pdf->Cell(0, 6, 'Target was HTTP; no SSL certificate checked.', 0, 1);
            return;
        }
        if (!empty($ssl['error'])) {
            $this->pdf->Cell(0, 6, 'Error: ' . $ssl['error'], 0, 1);
            return;
        }
        $this->pdf->Cell(0, 6, 'Subject: ' . ($ssl['subject_full'] ?? $ssl['subject_cn'] ?? 'N/A'), 0, 1);
        $this->pdf->Cell(0, 6, 'Issuer: ' . ($ssl['issuer_full'] ?? $ssl['issuer_cn'] ?? 'N/A'), 0, 1);
        $this->pdf->Cell(0, 6, 'Valid from: ' . ($ssl['valid_from'] ?? 'N/A') . ' — to: ' . ($ssl['valid_to'] ?? 'N/A'), 0, 1);
        $this->pdf->Cell(0, 6, 'Version: ' . ($ssl['version'] ?? 'N/A') . ' | Signature: ' . ($ssl['signature_algorithm'] ?? 'N/A'), 0, 1);
        $this->pdf->Cell(0, 6, 'Serial number: ' . ($ssl['serial_number'] ?? 'N/A'), 0, 1);
        if (!empty($ssl['key_type'])) {
            $keyInfo = $ssl['key_type'] . (!empty($ssl['key_bits']) ? ' ' . $ssl['key_bits'] . ' bits' : '');
            $this->pdf->Cell(0, 6, 'Public key: ' . $keyInfo, 0, 1);
        }
        if (!empty($ssl['fingerprint_sha256'])) {
            $this->pdf->Cell(0, 6, 'Fingerprint (SHA-256): ' . $ssl['fingerprint_sha256'], 0, 1);
        }
        if (!empty($ssl['fingerprint_sha1'])) {
            $this->pdf->Cell(0, 6, 'Fingerprint (SHA-1): ' . $ssl['fingerprint_sha1'], 0, 1);
        }
        if (!empty($ssl['vulnerable'])) {
            $this->pdf->SetFont('helvetica', 'B', 10);
            $this->pdf->SetTextColor(200, 80, 80);
            $this->pdf->Cell(0, 6, 'VULNERABLE: ' . ($ssl['vulnerable_reason'] ?? 'Certificate or protocol issue'), 0, 1);
            $this->pdf->SetTextColor(0, 0, 0);
            $this->pdf->SetFont('helvetica', '', 10);
        } else {
            $this->pdf->Cell(0, 6, 'No obvious certificate vulnerability detected.', 0, 1);
        }
    }

    private function addSecurityHeadersSection(array $data): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '4. Security Headers', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        $headers = $data['headers'] ?? [];
        if (empty($headers)) {
            $this->pdf->Cell(0, 6, 'No security headers data (HTTP or check skipped).', 0, 1);
            return;
        }
        foreach ($headers as $h) {
            $name = $h['header'] ?? '';
            $present = !empty($h['present']);
            $val = $present ? ($h['value'] ?? 'present') : '(missing)';
            $rec = $h['recommendation'] ?? '';
            $this->pdf->Cell(0, 6, ($present ? '[OK] ' : '[Missing] ') . $name . ': ' . $val, 0, 1);
            if ($rec !== '') $this->pdf->MultiCell(0, 5, '  Recommendation: ' . $rec, 0, 'L');
        }
    }

    private function addTlsQualitySection(array $data): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '5. TLS Quality', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($data)) {
            $this->pdf->Cell(0, 6, 'No TLS data (HTTP or check skipped).', 0, 1);
            return;
        }
        $this->pdf->Cell(0, 6, 'Protocol: ' . ($data['protocol'] ?? 'N/A') . ' | Cipher: ' . ($data['cipher'] ?? 'N/A'), 0, 1);
        if (!empty($data['weak'])) {
            $this->pdf->SetTextColor(200, 80, 80);
            $this->pdf->Cell(0, 6, 'Weak or deprecated TLS/cipher detected. Prefer TLS 1.2+ and strong ciphers.', 0, 1);
            $this->pdf->SetTextColor(0, 0, 0);
        } else {
            $this->pdf->Cell(0, 6, 'No weak TLS configuration detected.', 0, 1);
        }
    }

    private function addTechnologiesSection(array $tech): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '6. Technologies Detected', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($tech)) {
            $this->pdf->Cell(0, 6, 'No technologies detected.', 0, 1);
            return;
        }
        foreach ($tech as $t) {
            $name = $t['name'] ?? '';
            $version = $t['version'] ?? '';
            $source = $t['source'] ?? '';
            $this->pdf->Cell(0, 6, '- ' . $name . ($version !== '' ? ' ' . $version : '') . ($source !== '' ? ' (' . $source . ')' : ''), 0, 1);
        }
    }

    private function addRobotsSitemapSection(array $data): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '7. Robots.txt & Sitemap', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($data)) {
            $this->pdf->Cell(0, 6, 'No robots.txt or sitemap data.', 0, 1);
            return;
        }
        if (!empty($data['robots_txt'])) $this->pdf->Cell(0, 6, 'Robots.txt: fetched (' . strlen($data['robots_txt']) . ' bytes).', 0, 1);
        if (!empty($data['sitemap_urls'])) {
            $this->pdf->Cell(0, 6, 'Sitemaps:', 0, 1);
            foreach (array_slice($data['sitemap_urls'], 0, 20) as $s) $this->pdf->Cell(0, 5, '  - ' . $s, 0, 1);
        }
        if (!empty($data['disallow_paths'])) {
            $this->pdf->Cell(0, 6, 'Disallow paths (sample):', 0, 1);
            foreach (array_slice($data['disallow_paths'], 0, 15) as $r) $this->pdf->Cell(0, 5, '  - ' . $r, 0, 1);
        }
    }

    private function addSensitivePathsSection(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '8. Sensitive Paths', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No exposed sensitive paths found.', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $this->pdf->Cell(0, 6, '- ' . ($f['url'] ?? '') . ' [HTTP ' . ($f['status'] ?? '') . ']', 0, 1);
        }
    }

    private function addOpenRedirectsSection(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '9. Open Redirects', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No open redirect vulnerabilities found.', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $this->pdf->Cell(0, 6, 'URL: ' . ($f['url'] ?? ''), 0, 1);
            $this->pdf->Cell(0, 5, '  Parameter: ' . ($f['parameter'] ?? '') . ' | Redirects to: ' . ($f['redirect_to'] ?? ''), 0, 1);
        }
    }

    private function addSubdomainsSection(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '10. Subdomains', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No subdomains discovered (or subdomain scan not run).', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $this->pdf->Cell(0, 6, '- ' . ($f['subdomain'] ?? '') . ' → ' . ($f['ip'] ?? ''), 0, 1);
        }
    }

    private function addDirectoryFindings(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '11. Directory / File Discovery', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No accessible paths found.', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $url = $f['url'] ?? '';
            $status = $f['status'] ?? '';
            $type = $f['type'] ?? '';
            $this->pdf->Cell(0, 6, '- ' . $url . ' [HTTP ' . $status . '] (' . $type . ')', 0, 1);
        }
    }

    private function addAdminPagesSection(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '12. Possible admin pages', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No possible admin pages found (no 2xx/3xx responses on admin wordlist paths).', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $url = $f['url'] ?? '';
            $status = $f['status'] ?? '';
            $type = $f['type'] ?? '';
            $this->pdf->Cell(0, 6, '- ' . $url . ' [HTTP ' . $status . '] (' . $type . ')', 0, 1);
        }
    }

    private function addNmapFindings(array $nmap): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '13. Open Ports & Service Versions (Nmap)', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (!empty($nmap['error'])) {
            $this->pdf->MultiCell(0, 6, 'Error: ' . $nmap['error'], 0, 'L');
            return;
        }
        $ports = $nmap['ports'] ?? [];
        if (empty($ports)) {
            $this->pdf->Cell(0, 6, 'No open ports reported (or nmap not available).', 0, 1);
            if (!empty($nmap['raw'])) {
                $this->pdf->Ln(2);
                $this->pdf->SetFont('helvetica', '', 8);
                $this->pdf->MultiCell(0, 5, 'Raw output: ' . substr($nmap['raw'], 0, 2000), 0, 'L');
                $this->pdf->SetFont('helvetica', '', 10);
            }
            return;
        }
        foreach ($ports as $p) {
            $ver = trim($p['version'] ?? '');
            $line = 'Port ' . ($p['port'] ?? '') . ' | service: ' . ($p['service'] ?? '') . ' | version: ' . ($ver !== '' ? $ver : '(none detected)');
            $this->pdf->Cell(0, 6, $line, 0, 1);
        }
    }

    private function addSqlFindings(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '14. SQL Injection (Error-Verified) [Critical]', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No SQL injection vulnerabilities confirmed (no SQL errors observed).', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $this->pdf->SetFont('helvetica', 'B', 10);
            $this->pdf->Cell(0, 6, 'URL: ' . ($f['url'] ?? ''), 0, 1);
            $this->pdf->SetFont('helvetica', '', 10);
            $this->pdf->Cell(0, 6, 'Payload: ' . ($f['payload'] ?? ''), 0, 1);
            $this->pdf->Cell(0, 6, 'Evidence: ' . ($f['evidence'] ?? '') . ' | DB: ' . ($f['db_type'] ?? ''), 0, 1);
            $this->pdf->Ln(2);
        }
    }

    private function addXssFindings(array $findings): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '15. XSS Findings [High]', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($findings)) {
            $this->pdf->Cell(0, 6, 'No reflected XSS found with the tested payloads.', 0, 1);
            return;
        }
        foreach ($findings as $f) {
            $this->pdf->SetFont('helvetica', 'B', 10);
            $this->pdf->Cell(0, 6, 'URL: ' . ($f['url'] ?? ''), 0, 1);
            $this->pdf->SetFont('helvetica', '', 10);
            $this->pdf->Cell(0, 6, 'Payload: ' . ($f['payload'] ?? ''), 0, 1);
            $this->pdf->Cell(0, 6, 'Type: ' . ($f['type'] ?? 'reflected') . ' | ' . ($f['evidence'] ?? ''), 0, 1);
            $this->pdf->Ln(2);
        }
    }

    private function addCveFindings(array $cveList): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '16. CVE Vulnerabilities & Fixes', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        if (empty($cveList)) {
            $this->pdf->Cell(0, 6, 'No CVE entries included (or NVD API unavailable).', 0, 1);
            return;
        }
        foreach ($cveList as $c) {
            $this->pdf->SetFont('helvetica', 'B', 10);
            $this->pdf->Cell(0, 6, ($c['id'] ?? '') . ' | CVSS: ' . ($c['cvss_score'] ?? '') . ' | ' . ($c['severity'] ?? ''), 0, 1);
            $this->pdf->SetFont('helvetica', '', 9);
            $this->pdf->MultiCell(0, 5, 'Description: ' . substr($c['description'] ?? '', 0, 500), 0, 'L');
            $this->pdf->Cell(0, 5, 'How to fix: ' . ($c['fix'] ?? 'N/A'), 0, 1);
            foreach (array_slice($c['references'] ?? [], 0, 3) as $ref) {
                $this->pdf->SetFont('helvetica', '', 8);
                $this->pdf->Cell(0, 4, $ref, 0, 1, '', false, $ref);
            }
            $this->pdf->SetFont('helvetica', '', 10);
            $this->pdf->Ln(3);
        }
    }

    private function addRemediationSummary(array $scanResults): void
    {
        $this->pdf->AddPage();
        $this->pdf->SetFont('helvetica', 'B', 14);
        $this->pdf->Cell(0, 8, '17. Remediation Summary', 0, 1);
        $this->pdf->SetFont('helvetica', '', 10);
        $lines = [];
        $ssl = $scanResults['ssl'] ?? null;
        if ($ssl !== null && !empty($ssl['vulnerable'])) {
            $lines[] = '- SSL: Renew or replace the certificate; avoid SHA-1; use TLS 1.2+ only.';
        }
        if (!empty($scanResults['directory'])) {
            $lines[] = '- Restrict directory listing and remove or protect sensitive paths (admin, backup, config, .git, .env).';
        }
        if (!empty($scanResults['admin_pages'])) {
            $lines[] = '- Restrict or protect admin/backend panels; use strong authentication and IP allowlisting.';
        }
        if (!empty($scanResults['nmap']['ports'])) {
            $lines[] = '- Harden exposed services: update to latest versions, disable unnecessary ports, use firewall rules.';
        }
        if (!empty($scanResults['sql'])) {
            $lines[] = '- Fix SQL injection: use prepared statements/parameterized queries; never concatenate user input into SQL.';
        }
        if (!empty($scanResults['xss'])) {
            $lines[] = '- Fix XSS: encode output (HTML entity encode); use Content-Security-Policy; avoid inserting user input into HTML/JS.';
        }
        if (!empty($scanResults['cve'])) {
            $lines[] = '- Apply patches and upgrades per CVE recommendations; follow vendor security advisories.';
        }
        if (empty($lines)) {
            $lines[] = 'No high-level findings; maintain good hygiene (updates, least privilege, input validation).';
        }
        foreach ($lines as $line) {
            $this->pdf->MultiCell(0, 6, $line, 0, 'L');
        }
    }
}
