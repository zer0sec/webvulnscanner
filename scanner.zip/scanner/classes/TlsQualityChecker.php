<?php
/**
 * Check TLS version and weak ciphers (when SSL is present).
 */

class TlsQualityChecker
{
    private string $host;
    private int $port;
    private int $timeout;

    public function __construct(string $host, int $port = 443, int $timeout = 10)
    {
        $this->host = $host;
        $this->port = $port;
        $this->timeout = $timeout;
    }

    public function run(): array
    {
        $result = ['protocol' => '', 'cipher' => '', 'weak' => false, 'issues' => []];
        $ctx = stream_context_create([
            'ssl' => [
                'capture_peer_cert_chain' => false,
                'verify_peer' => false,
            ],
        ]);
        $fp = @stream_socket_client(
            'ssl://' . $this->host . ':' . $this->port,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $ctx
        );
        if (!$fp) {
            $result['error'] = $errstr ?: 'Could not connect';
            return $result;
        }
        $params = stream_context_get_params($fp);
        $cipher = $params['options']['ssl']['cipher_name'] ?? '';
        $version = $params['options']['ssl']['protocol'] ?? '';
        fclose($fp);
        $result['protocol'] = $version;
        $result['cipher'] = $cipher;
        if (stripos($version, 'TLSv1.0') !== false || stripos($version, 'SSLv3') !== false) {
            $result['weak'] = true;
            $result['issues'][] = 'Weak or deprecated protocol: ' . $version;
        }
        if (stripos($cipher, 'NULL') !== false || stripos($cipher, 'EXPORT') !== false || stripos($cipher, 'RC4') !== false) {
            $result['weak'] = true;
            $result['issues'][] = 'Weak cipher: ' . $cipher;
        }
        return $result;
    }
}
