<?php
/**
 * Reflected XSS scanner using a payload wordlist.
 * Injects payloads into query string and checks if payload appears in response (reflected).
 */

class XssScanner
{
    private string $baseUrl;
    private int $timeout;
    private int $maxPayloads;
    private array $payloads = [];
    private array $found = [];

    public function __construct(string $baseUrl, int $timeout = 10, int $maxPayloads = 500)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
        $this->maxPayloads = $maxPayloads;
    }

    /**
     * Load wordlist from URL or local file. Returns true if loaded.
     */
    public function loadWordlist(string $urlOrPath): bool
    {
        $lines = [];
        if (preg_match('#^https?://#i', $urlOrPath)) {
            $ctx = stream_context_create(['http' => ['timeout' => 30]]);
            $content = @file_get_contents($urlOrPath, false, $ctx);
            if ($content === false) {
                return false;
            }
            $lines = preg_split('/\r?\n/', $content);
        } else {
            if (!is_readable($urlOrPath)) {
                return false;
            }
            $lines = file($urlOrPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        }
        $this->payloads = array_values(array_unique(array_filter(array_map('trim', $lines))));
        $this->payloads = array_slice($this->payloads, 0, $this->maxPayloads);
        return count($this->payloads) > 0;
    }

    public function setPayloads(array $payloads): void
    {
        $this->payloads = array_slice($payloads, 0, $this->maxPayloads);
    }

    /**
     * Run scan: append payload to base URL as ?q=PAYLOAD (and one common param). Optional progress callback (current, total, message).
     */
    public function run(?callable $progress = null): array
    {
        $this->found = [];
        $total = count($this->payloads);
        if ($total === 0) {
            return $this->found;
        }
        $param = 'q';
        foreach ($this->payloads as $i => $payload) {
            if ($progress && ($i % 10 === 0 || $i === $total - 1)) {
                $progress($i + 1, $total, 'XSS test ' . ($i + 1) . '/' . $total);
            }
            $testUrl = $this->baseUrl . (strpos($this->baseUrl, '?') !== false ? '&' : '?') . $param . '=' . urlencode($payload);
            $reflected = $this->probe($testUrl, $payload);
            if ($reflected !== null) {
                $this->found[] = $reflected;
            }
        }
        return $this->found;
    }

    private function probe(string $url, string $payload): ?array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 2,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code !== 200 || $body === false) {
            return null;
        }
        $decoded = html_entity_decode($body, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (strpos($decoded, $payload) !== false) {
            return [
                'url' => $url,
                'payload' => $payload,
                'type' => 'reflected',
                'evidence' => 'Payload reflected in response body',
            ];
        }
        return null;
    }

    public function getFound(): array
    {
        return $this->found;
    }
}
