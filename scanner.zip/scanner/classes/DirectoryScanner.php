<?php
/**
 * Directory and file discovery scanner.
 * Probes common paths and reports accessible URLs.
 */

class DirectoryScanner
{
    private string $baseUrl;
    private int $timeout;
    private int $delayMs;
    private array $found = [];
    private array $wordlist = [];

    public function __construct(string $baseUrl, int $timeout = 10, int $delayMs = 0)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->timeout = $timeout;
        $this->delayMs = max(0, $delayMs);
    }

    public function loadWordlist(string $path): bool
    {
        if (!is_readable($path)) {
            return false;
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $this->wordlist = array_map('trim', $lines);
        return count($this->wordlist) > 0;
    }

    public function setWordlist(array $paths): void
    {
        $this->wordlist = $paths;
    }

    public function getWordlistCount(): int
    {
        return count($this->wordlist);
    }

    /**
     * Run scan. Optional $progress callback receives (currentIndex, totalCount) for percentage progress.
     */
    public function run(?callable $progress = null): array
    {
        $this->found = [];
        $total = count($this->wordlist);
        foreach ($this->wordlist as $i => $path) {
            if ($progress && ($i % 20 === 0 || $i === $total - 1)) {
                $progress($i + 1, $total);
            }
            $path = ltrim($path, '/');
            $url = $this->baseUrl . '/' . $path;
            $result = $this->probe($url);
            if ($result !== null) {
                $this->found[] = $result;
            }
            if ($this->delayMs > 0 && $i < $total - 1) {
                usleep($this->delayMs * 1000);
            }
        }
        return $this->found;
    }

    private function probe(string $url): ?array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'VulnScanner/1.0',
        ]);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        if ($code >= 200 && $code < 400) {
            return [
                'url' => $url,
                'status' => $code,
                'type' => $code === 200 ? 'file_or_dir' : 'redirect',
                'content_type' => $contentType ?: '',
            ];
        }
        return null;
    }

    public function getFound(): array
    {
        return $this->found;
    }
}
