<?php
/**
 * SSL/TLS certificate checker for HTTPS targets.
 * Fetches cert details and flags weak/vulnerable protocol versions.
 */

class SslChecker
{
    private string $host;
    private int $port;
    private int $timeout;

    public function __construct(string $host, int $port = 443, int $timeout = 10)
    {
        $this->host = $host;
        $this->port = $port;
        $this->timeout = $timeout;
    }

    /**
     * Run check. Returns array with cert info and vulnerable flag, or error.
     */
    public function run(): array
    {
        $ctx = stream_context_create([
            'ssl' => [
                'capture_peer_cert' => true,
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ]);
        $errno = 0;
        $errstr = '';
        $target = 'ssl://' . $this->host . ':' . $this->port;
        $fp = @stream_socket_client($target, $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT, $ctx);
        if (!$fp) {
            return ['error' => $errstr ?: 'Could not connect to ' . $this->host . ':' . $this->port];
        }
        $params = stream_context_get_params($fp);
        fclose($fp);
        $cert = $params['options']['ssl']['peer_certificate'] ?? null;
        if (!$cert) {
            return ['error' => 'No certificate received'];
        }
        $certRes = is_resource($cert) ? $cert : @openssl_x509_read($cert);
        $info = openssl_x509_parse($cert);
        if ($info === false) {
            return ['error' => 'Failed to parse certificate'];
        }
        $subject = $info['subject'] ?? [];
        $issuer = $info['issuer'] ?? [];
        $validFrom = isset($info['validFrom_time_t']) ? date('Y-m-d H:i:s', $info['validFrom_time_t']) : '';
        $validTo = isset($info['validTo_time_t']) ? date('Y-m-d H:i:s', $info['validTo_time_t']) : '';
        $cn = $subject['CN'] ?? implode(', ', array_map(function ($k, $v) {
            return $k . '=' . (is_array($v) ? $v[0] : $v);
        }, array_keys($subject), $subject));
        if (is_array($cn)) {
            $cn = $cn[0] ?? json_encode($cn);
        }
        $issuerCn = $issuer['CN'] ?? '';
        if (is_array($issuerCn)) {
            $issuerCn = $issuerCn[0] ?? '';
        }
        $version = $info['version'] ?? 0;
        $sigAlg = $info['signatureTypeSN'] ?? ($info['signatureTypeLN'] ?? '');
        $serial = isset($info['serialNumber']) ? $info['serialNumber'] : '';
        $serialHex = isset($info['serialNumberHex']) ? $info['serialNumberHex'] : '';

        $subjectFull = $this->formatDn($subject);
        $issuerFull = $this->formatDn($issuer);

        $fingerprintSha256 = '';
        $fingerprintSha1 = '';
        if (function_exists('openssl_x509_fingerprint') && $certRes !== false) {
            $fingerprintSha256 = @openssl_x509_fingerprint($certRes, 'sha256') ?: '';
            $fingerprintSha1 = @openssl_x509_fingerprint($certRes, 'sha1') ?: '';
        }

        $keyType = '';
        $keyBits = '';
        $pubKey = ($certRes !== false && function_exists('openssl_x509_get_public_key')) ? @openssl_x509_get_public_key($certRes) : null;
        if (is_resource($pubKey) || $pubKey instanceof \OpenSSLAsymmetricKey) {
            $details = @openssl_pkey_get_details($pubKey);
            if (is_array($details)) {
                $keyType = $details['type'] ?? '';
                if ($keyType === OPENSSL_KEYTYPE_RSA && isset($details['bits'])) {
                    $keyType = 'RSA';
                    $keyBits = (string) $details['bits'];
                } elseif ($keyType === OPENSSL_KEYTYPE_EC && isset($details['bits'])) {
                    $keyType = 'EC';
                    $keyBits = (string) $details['bits'];
                } elseif (defined('OPENSSL_KEYTYPE_DSA') && $keyType === OPENSSL_KEYTYPE_DSA && isset($details['bits'])) {
                    $keyType = 'DSA';
                    $keyBits = (string) $details['bits'];
                }
            }
        }

        $vulnerable = false;
        $vulnerableReason = '';
        if (!empty($info['validTo_time_t']) && $info['validTo_time_t'] < time()) {
            $vulnerable = true;
            $vulnerableReason = 'Certificate expired';
        }
        if (strpos(strtolower($sigAlg), 'sha1') !== false && strpos(strtolower($sigAlg), 'sha256') === false) {
            $vulnerable = true;
            $vulnerableReason = ($vulnerableReason ? $vulnerableReason . '; ' : '') . 'Weak signature (SHA-1)';
        }

        return [
            'error' => null,
            'subject_cn' => $cn,
            'subject_full' => $subjectFull,
            'issuer_cn' => $issuerCn,
            'issuer_full' => $issuerFull,
            'valid_from' => $validFrom,
            'valid_to' => $validTo,
            'version' => $version,
            'signature_algorithm' => $sigAlg,
            'serial_number' => $serial ?: $serialHex,
            'fingerprint_sha256' => $fingerprintSha256,
            'fingerprint_sha1' => $fingerprintSha1,
            'key_type' => $keyType,
            'key_bits' => $keyBits,
            'vulnerable' => $vulnerable,
            'vulnerable_reason' => $vulnerableReason ?: null,
        ];
    }

    private function formatDn(array $arr): string
    {
        $parts = [];
        foreach ($arr as $k => $v) {
            $val = is_array($v) ? ($v[0] ?? json_encode($v)) : $v;
            $parts[] = $k . '=' . $val;
        }
        return implode(', ', $parts);
    }
}
