<?php
/**
 * Optional subdomain discovery using a small wordlist (used in full profile).
 */

class SubdomainFinder
{
    private string $domain;
    private int $timeout;
    private int $maxSubdomains;

    private static array $defaultList = ['www', 'mail', 'ftp', 'admin', 'dev', 'staging', 'api', 'app', 'blog', 'shop', 'cdn', 'static', 'secure', 'm', 'mobile', 'test', 'demo'];

    public function __construct(string $domain, int $timeout = 5, int $maxSubdomains = 20)
    {
        $this->domain = $domain;
        $this->timeout = $timeout;
        $this->maxSubdomains = $maxSubdomains;
    }

    public function run(): array
    {
        $found = [];
        $list = array_slice(self::$defaultList, 0, $this->maxSubdomains);
        foreach ($list as $sub) {
            $host = $sub . '.' . $this->domain;
            $ip = @gethostbyname($host);
            if ($ip !== $host) {
                $found[] = ['subdomain' => $host, 'ip' => $ip];
            }
        }
        return $found;
    }
}
