<?php
/**
 * WHOIS lookup for a host or IP.
 * Tries system whois command first; falls back to socket connection to WHOIS server if not available.
 */

class WhoisLookup
{
    private string $query;
    private int $timeout;

    public function __construct(string $hostOrIp, int $timeout = 15)
    {
        $this->query = trim($hostOrIp);
        $this->timeout = $timeout;
    }

    /**
     * Run whois. Returns raw text or error message.
     * Tries 'whois' command first; on failure (e.g. Windows without whois) uses socket to whois server.
     */
    public function run(): array
    {
        $safe = preg_replace('/[^a-zA-Z0-9.\-_]/', '', $this->query);
        if ($safe === '') {
            return ['raw' => '', 'error' => 'Invalid host or IP'];
        }
        $result = $this->runViaCommand($safe);
        if ($result !== null) {
            return $result;
        }
        return $this->runViaSocket($safe);
    }

    private function runViaCommand(string $safe): ?array
    {
        $cmd = 'whois ' . $safe . ' 2>&1';
        $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $p = @proc_open($cmd, $descriptors, $pipes, null, null, ['bypass_shell' => true]);
        if (!is_resource($p)) {
            return null;
        }
        fclose($pipes[0]);
        $raw = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        if (isset($pipes[2])) {
            fclose($pipes[2]);
        }
        proc_close($p);
        $raw = $raw !== false ? trim((string) $raw) : '';
        if ($raw === '' || stripos($raw, 'not recognized') !== false || stripos($raw, 'command not found') !== false || stripos($raw, 'whois: command not found') !== false) {
            return null;
        }
        return ['raw' => $raw, 'error' => null];
    }

    private function runViaSocket(string $safe): array
    {
        $isIp = filter_var($safe, FILTER_VALIDATE_IP);
        $server = $isIp ? 'whois.iana.org' : 'whois.internic.net';
        $fp = @fsockopen($server, 43, $errno, $errstr, $this->timeout);
        if (!$fp || !is_resource($fp)) {
            return ['raw' => '', 'error' => 'WHOIS unavailable (whois command not installed and socket fallback failed: ' . ($errstr ?: 'connection failed') . ')'];
        }
        stream_set_timeout($fp, $this->timeout);
        if (@fwrite($fp, $safe . "\r\n") === false) {
            fclose($fp);
            return ['raw' => '', 'error' => 'WHOIS write failed'];
        }
        $raw = '';
        while (!feof($fp)) {
            $chunk = @fread($fp, 8192);
            if ($chunk === false) {
                break;
            }
            $raw .= $chunk;
        }
        fclose($fp);
        $raw = trim($raw);
        if ($raw === '') {
            return ['raw' => '', 'error' => 'WHOIS server returned no data'];
        }
        return ['raw' => $raw, 'error' => null];
    }
}
