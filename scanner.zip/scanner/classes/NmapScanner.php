<?php
/**
 * Nmap-based port and version scanner.
 * Requires nmap installed; resolves path on Windows (Apache often has no PATH).
 */

class NmapScanner
{
    private string $host;
    private int $timeout;
    private string $nmapPath;
    private array $results = [];

    public function __construct(string $host, int $timeout = 120, string $nmapPath = '')
    {
        $this->host = $host;
        $this->timeout = $timeout;
        $this->nmapPath = $this->resolveNmapPath($nmapPath);
    }

    /**
     * Resolve nmap executable path. On Windows, Apache often doesn't have nmap in PATH.
     */
    private function resolveNmapPath(string $configured): string
    {
        if ($configured !== '' && is_executable($configured)) {
            return $configured;
        }
        if ($configured !== '') {
            return $configured;
        }
        $name = (DIRECTORY_SEPARATOR === '\\') ? 'nmap.exe' : 'nmap';
        $paths = [$name];
        if (DIRECTORY_SEPARATOR === '\\') {
            $pf = getenv('ProgramFiles') ?: 'C:\\Program Files';
            $pf86 = getenv('ProgramFiles(x86)') ?: 'C:\\Program Files (x86)';
            $paths[] = $pf . '\\Nmap\\nmap.exe';
            $paths[] = $pf86 . '\\Nmap\\nmap.exe';
            $paths[] = 'C:\\laragon\\bin\\nmap\\nmap.exe';
            $paths[] = 'C:\\laragon\\bin\\nmap\\nmap';
        }
        foreach ($paths as $p) {
            if (@is_executable($p)) {
                return $p;
            }
            if (DIRECTORY_SEPARATOR === '\\' && preg_match('/^[a-z]+$/i', $p)) {
                continue;
            }
        }
        return $name;
    }

    /**
     * Start nmap in background; returns a handle to collect later with collectAsync().
     */
    public function runAsync(): ?array
    {
        $exe = $this->nmapPath;
        $host = $this->host;
        $args = '-Pn -sV -sT -T4 --open --min-rate=500 -oG -';
        if (DIRECTORY_SEPARATOR === '\\') {
            $cmd = '"' . str_replace('"', '""', $exe) . '" ' . $args . ' "' . str_replace('"', '""', $host) . '" 2>&1';
        } else {
            $cmd = escapeshellcmd($exe) . ' ' . $args . ' ' . escapeshellarg($host) . ' 2>&1';
        }
        $descriptor = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $proc = @proc_open($cmd, $descriptor, $pipes, null, null, ['timeout' => $this->timeout]);
        if (!is_resource($proc)) {
            return null;
        }
        fclose($pipes[0]);
        return ['proc' => $proc, 'pipes' => $pipes];
    }

    /**
     * Collect result from a handle returned by runAsync(). Blocks until nmap finishes.
     */
    public function collectAsync(?array $handle): array
    {
        $this->results = ['ports' => [], 'raw' => '', 'error' => null];
        if ($handle === null || !isset($handle['proc'], $handle['pipes'])) {
            $this->results['error'] = 'Nmap failed to start or handle invalid.';
            return $this->results;
        }
        $pipes = $handle['pipes'];
        $stdout = stream_get_contents($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($handle['proc']);
        $all = $stdout . "\n" . $stderr;
        $this->results['raw'] = $all;
        $this->parseOutput($all);
        if (count($this->results['ports']) === 0 && trim($stderr) !== '') {
            $this->results['error'] = trim($stderr);
        }
        return $this->results;
    }

    /**
     * Run nmap and optionally stream each line of output to $lineCallback (e.g. for live log).
     */
    public function runWithOutput(?callable $lineCallback = null): array
    {
        $this->results = ['ports' => [], 'raw' => '', 'error' => null];
        $exe = $this->nmapPath;
        $host = $this->host;
        $args = '-Pn -sV -sT -T4 --open --min-rate=500';
        if (DIRECTORY_SEPARATOR === '\\') {
            $cmd = '"' . str_replace('"', '""', $exe) . '" ' . $args . ' "' . str_replace('"', '""', $host) . '" 2>&1';
        } else {
            $cmd = escapeshellcmd($exe) . ' ' . $args . ' ' . escapeshellarg($host) . ' 2>&1';
        }
        $descriptor = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $proc = @proc_open($cmd, $descriptor, $pipes, null, null, ['timeout' => $this->timeout]);
        if (!is_resource($proc)) {
            $this->results['error'] = 'Failed to run nmap. Install nmap and ensure proc_open/exec are allowed. On Windows, set NMAP_PATH in config to the full path to nmap.exe.';
            return $this->results;
        }
        fclose($pipes[0]);
        $all = '';
        while (!feof($pipes[1])) {
            $line = @fgets($pipes[1]);
            if ($line !== false) {
                $all .= $line;
                if ($lineCallback !== null && trim($line) !== '') {
                    $lineCallback(trim($line));
                }
            }
        }
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($proc);
        $all .= "\n" . $stderr;
        $this->results['raw'] = $all;
        $this->parseOutput($all);
        if (count($this->results['ports']) === 0 && trim($stderr) !== '') {
            $this->results['error'] = trim($stderr);
        }
        return $this->results;
    }

    public function run(): array
    {
        return $this->runWithOutput(null);
    }

    private function parseOutput(string $output): void
    {
        $this->parseGrepableOutput($output);
        if (count($this->results['ports']) === 0) {
            $this->parseNormalOutput($output);
        }
    }

    /** Parse nmap -oG (grepable) format: Ports: 80/open/tcp//http//... */
    private function parseGrepableOutput(string $output): void
    {
        if (!preg_match('/Ports:\s*(.+?)(?:\s*Ignored|\s*$)/s', $output, $m)) {
            return;
        }
        $portStr = $m[1];
        if (preg_match_all('/(\d+)\/open\/tcp\/\/([^\/]*)\/\/(.*?)(?:\/,\s*|\/)\s*/s', $portStr . '/ ', $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $version = isset($match[3]) ? trim(str_replace('/', ' ', $match[3])) : '';
                $this->results['ports'][] = [
                    'port' => (int) $match[1],
                    'state' => 'open',
                    'service' => trim($match[2]) ?: 'unknown',
                    'version' => $version,
                ];
            }
        }
    }

    /** Fallback: parse normal nmap-style lines (e.g. "80/tcp open http") from raw output */
    private function parseNormalOutput(string $output): void
    {
        foreach (explode("\n", $output) as $line) {
            $line = trim($line);
            if (preg_match('/^(\d+)\/tcp\s+open\s+(\S+)(?:\s+(.*))?$/i', $line, $m)) {
                $this->results['ports'][] = [
                    'port' => (int) $m[1],
                    'state' => 'open',
                    'service' => $m[2],
                    'version' => isset($m[3]) ? trim($m[3]) : '',
                ];
            }
        }
    }

    public function getResults(): array
    {
        return $this->results;
    }
}
