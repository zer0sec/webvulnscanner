<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Vulnerability Scanner';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0d1117;
            --surface: #161b22;
            --border: #30363d;
            --text: #e6edf3;
            --text-muted: #8b949e;
            --accent: #58a6ff;
            --accent-dim: #388bfd;
            --danger: #f85149;
            --success: #3fb950;
            --warn: #d29922;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Outfit', sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.5;
        }
        .wrap {
            max-width: 640px;
            margin: 0 auto;
            padding: 2rem 1.5rem;
        }
        h1 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            letter-spacing: -0.02em;
        }
        .sub {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin-bottom: 2rem;
        }
        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        input[type="url"], input[type="text"] {
            width: 100%;
            padding: 0.75rem 1rem;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.95rem;
            background: var(--bg);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
        }
        input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(88, 166, 255, 0.2);
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.25rem;
            font-family: inherit;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.2s, transform 0.05s;
        }
        .btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .btn-primary {
            background: var(--accent);
            color: #fff;
        }
        .btn-primary:hover:not(:disabled) {
            background: var(--accent-dim);
        }
        .btn-primary:active:not(:disabled) { transform: scale(0.98); }
        .btn-download {
            background: var(--success);
            color: #fff;
            text-decoration: none;
            margin-top: 0.75rem;
        }
        .btn-download:hover { background: #2ea043; }
        .btn-export {
            background: var(--surface);
            color: var(--text);
            border: 1px solid var(--border);
        }
        .btn-export:hover { border-color: var(--accent); }
        .progress {
            margin-top: 1rem;
            display: none;
        }
        .progress.visible { display: block; }
        .progress-text {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
        }
        .bar {
            height: 6px;
            background: var(--border);
            border-radius: 3px;
            overflow: hidden;
        }
        .bar-fill {
            height: 100%;
            width: 30%;
            background: var(--accent);
            border-radius: 3px;
            animation: pulse 1.2s ease-in-out infinite;
        }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
        .result {
            margin-top: 1rem;
            display: none;
        }
        .result.visible { display: block; }
        .result.error .result-msg { color: var(--danger); }
        .result.success .result-msg { color: var(--success); }
        .result-msg { margin-bottom: 0.5rem; font-weight: 500; }
        .result-meta {
            font-size: 0.85rem;
            color: var(--text-muted);
        }
        .terminal-wrap {
            margin-top: 1rem;
        }
        .terminal-wrap label {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 0.35rem;
        }
        .terminal {
            background: #0c0c0c;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.8rem;
            color: #9ccc9c;
            padding: 0.75rem 1rem;
            min-height: 320px;
            max-height: 480px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-all;
            line-height: 1.4;
        }
        .terminal:empty::before {
            content: 'Waiting for output…';
            color: var(--text-muted);
        }
        .scan-note {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-top: 1rem;
            line-height: 1.5;
        }
        .disclaimer {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border);
        }
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .modal-overlay.visible { display: flex; }
        .modal-box {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
            max-width: 360px;
            text-align: center;
        }
        .modal-box p { margin: 0 0 1.25rem; line-height: 1.5; }
        .modal-box .btn { margin: 0; }
    </style>
</head>
<body>
    <div class="wrap">
        <h1>Vulnerability Scanner</h1>
        <p class="sub">WHOIS, Nmap, XSS, SQL injection, security headers, TLS, tech detection, robots/sitemap, sensitive paths, open redirects, subdomains (full) → PDF report</p>

        <div class="card">
            <form id="scan-form">
                <label for="target_url">Target URL</label>
                <input type="url" id="target_url" name="target_url" placeholder="https://example.com" required>

                <label for="profile" style="margin-top: 1rem;">Scan profile</label>
                <select id="profile" name="profile" style="width: 100%; padding: 0.75rem 1rem; font-size: 0.95rem; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; color: var(--text);">
                    <option value="quick">Quick (smaller wordlists, no subdomains)</option>
                    <option value="full" selected>Full (full wordlists + subdomain discovery)</option>
                </select>

                <details style="margin-top: 1rem;">
                    <summary style="cursor: pointer; color: var(--text-muted); font-size: 0.9rem;">Optional: Auth &amp; exclude paths</summary>
                    <label for="auth_user" style="margin-top: 0.75rem;">HTTP Basic username</label>
                    <input type="text" id="auth_user" name="auth_user" placeholder="(optional)">
                    <label for="auth_pass">HTTP Basic password</label>
                    <input type="password" id="auth_pass" name="auth_pass" placeholder="(optional)">
                    <label for="exclude_paths">Exclude paths (comma-separated)</label>
                    <textarea id="exclude_paths" name="exclude_paths" placeholder="e.g. logout, api/health" rows="2" style="width: 100%; padding: 0.75rem; font-family: 'JetBrains Mono', monospace; font-size: 0.9rem; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; color: var(--text); resize: vertical;"></textarea>
                </details>

                <button type="submit" class="btn btn-primary" id="btn-scan" style="margin-top: 1rem;">
                    Run scan &amp; generate PDF
                </button>
            </form>

            <div class="progress" id="progress">
                <div class="progress-text" id="progress-text">Scanning… This may take 1–2 minutes.</div>
                <div class="bar"><div class="bar-fill"></div></div>
            </div>

            <div class="terminal-wrap">
                <label>Live log</label>
                <pre class="terminal" id="terminal" aria-live="polite"></pre>
            </div>

            <div class="result" id="result">
                <div class="result-msg" id="result-msg"></div>
                <div class="result-meta" id="result-meta"></div>
                <a id="report-link" class="btn btn-download" href="#" download style="display: none;">Download PDF report</a>
                <div id="export-buttons" style="display: none; margin-top: 0.5rem; gap: 0.5rem; flex-wrap: wrap;">
                    <button type="button" class="btn btn-export" id="btn-export-json">Export JSON</button>
                    <button type="button" class="btn btn-export" id="btn-export-csv">Export CSV</button>
                </div>
            </div>
        </div>

        <div class="card" id="history-card">
            <label>Scan history</label>
            <div id="history-list" style="font-size: 0.9rem; color: var(--text-muted);">Loading…</div>
        </div>

        <p class="scan-note">
            Directory and admin-panel scans use a <strong><?php echo (int)(defined('SCAN_REQUEST_DELAY_MS') ? SCAN_REQUEST_DELAY_MS : 200); ?> ms</strong> delay between requests to avoid triggering WAFs or ModSecurity and reduce the risk of your IP being blocked.
        </p>

        <p class="disclaimer">
            Use only on systems you are authorized to test. Unauthorized scanning may be illegal. We are not responsible for how you use our product.
        </p>
    </div>

    <div class="modal-overlay" id="coffee-modal" aria-hidden="true">
        <div class="modal-box">
            <p>This may take a while — go make a coffee!</p>
            <button type="button" class="btn btn-primary" id="coffee-modal-ok">OK</button>
        </div>
    </div>

    <script>
        (function () {
            var form = document.getElementById('scan-form');
            var progress = document.getElementById('progress');
            var result = document.getElementById('result');
            var resultMsg = document.getElementById('result-msg');
            var resultMeta = document.getElementById('result-meta');
            var reportLink = document.getElementById('report-link');
            var btn = document.getElementById('btn-scan');
            var terminal = document.getElementById('terminal');
            var exportButtons = document.getElementById('export-buttons');
            var lastScanResult = null;

            function terminalAppend(text) {
                terminal.textContent += text;
                terminal.scrollTop = terminal.scrollHeight;
            }

            function loadHistory() {
                var listEl = document.getElementById('history-list');
                fetch('api/scan-history.php')
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        var items = data.history || [];
                        if (items.length === 0) {
                            listEl.innerHTML = 'No scans yet.';
                            return;
                        }
                        listEl.innerHTML = items.map(function (item) {
                            var reportLink = item.report ? '<a href="reports/' + item.report + '" style="color: var(--accent);">Report</a>' : '—';
                            return '<div style="margin-bottom: 0.35rem;">' + new Date(item.at).toLocaleString() + ' — ' + item.url + ' — ' + (item.ok ? '<span style="color: var(--success);">OK</span>' : '<span style="color: var(--danger);">Failed</span>') + ' — ' + reportLink + '</div>';
                        }).join('');
                    })
                    .catch(function () { listEl.innerHTML = 'Could not load history.'; });
            }
            loadHistory();

            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var url = document.getElementById('target_url').value.trim();
                if (!url) return;
                if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
                var profile = (document.getElementById('profile') && document.getElementById('profile').value) || 'full';
                var authUser = (document.getElementById('auth_user') && document.getElementById('auth_user').value) || '';
                var authPass = (document.getElementById('auth_pass') && document.getElementById('auth_pass').value) || '';
                var excludePaths = (document.getElementById('exclude_paths') && document.getElementById('exclude_paths').value.trim()) || '';

                result.classList.remove('visible', 'error', 'success');
                resultMsg.textContent = '';
                resultMeta.textContent = '';
                reportLink.style.display = 'none';
                exportButtons.style.display = 'none';
                lastScanResult = null;
                btn.disabled = true;
                terminal.textContent = '';
                terminalAppend('Checking if website is reachable…\n');

                fetch('api/check-url.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ target_url: url })
                })
                .then(function (r) { return r.json(); })
                .then(function (check) {
                    if (!check.valid) {
                        btn.disabled = false;
                        result.classList.add('visible', 'error');
                        resultMsg.textContent = 'Invalid website';
                        resultMeta.textContent = check.error || 'The URL could not be reached.';
                        terminalAppend('Invalid website: ' + (check.error || '') + '\n');
                        return;
                    }
                    terminalAppend('Website is reachable.\n');
                    var modal = document.getElementById('coffee-modal');
                    modal.classList.add('visible');
                    modal.setAttribute('aria-hidden', 'false');
                    document.getElementById('coffee-modal-ok').focus();
                })
                .catch(function (err) {
                    btn.disabled = false;
                    result.classList.add('visible', 'error');
                    resultMsg.textContent = 'Invalid website';
                    resultMeta.textContent = err.message || 'Could not check URL.';
                    terminalAppend('Check failed: ' + (err.message || '') + '\n');
                });
            });

            document.getElementById('coffee-modal-ok').addEventListener('click', function () {
                var modal = document.getElementById('coffee-modal');
                modal.classList.remove('visible');
                modal.setAttribute('aria-hidden', 'true');
                startScan();
            });

            function startScan() {
                var url = document.getElementById('target_url').value.trim();
                if (!url) return;
                if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
                var profile = (document.getElementById('profile') && document.getElementById('profile').value) || 'full';
                var authUser = (document.getElementById('auth_user') && document.getElementById('auth_user').value) || '';
                var authPass = (document.getElementById('auth_pass') && document.getElementById('auth_pass').value) || '';
                var excludePaths = (document.getElementById('exclude_paths') && document.getElementById('exclude_paths').value.trim()) || '';

                progress.classList.add('visible');
                btn.disabled = true;
                terminalAppend('Starting scan for ' + url + ' (profile: ' + profile + ')\n');

                var progressText = document.getElementById('progress-text');
                progressText.textContent = 'Starting scan…';

                var body = { target_url: url, profile: profile };
                if (authUser) body.auth_user = authUser;
                if (authPass) body.auth_pass = authPass;
                if (excludePaths) body.exclude_paths = excludePaths;

                fetch('api/run-scan.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                })
                .then(function (response) {
                    var reader = response.body.getReader();
                    var decoder = new TextDecoder();
                    var buffer = '';
                    var barFill = progress.querySelector('.bar-fill');
                    function processLine(line) {
                        line = line.trim();
                        if (!line) return false;
                        try {
                            var data = JSON.parse(line);
                            if (data.type === 'progress') {
                                var pct = typeof data.percent === 'number' ? data.percent : 0;
                                barFill.style.width = pct + '%';
                                progressText.textContent = (pct > 0 ? pct + '% – ' : '') + (data.message || 'Scanning…');
                                terminalAppend('[' + pct + '%] ' + (data.message || '') + '\n');
                                return false;
                            }
                            if (data.type === 'log') {
                                terminalAppend((data.line || '') + '\n');
                                return false;
                            }
                            if (data.type === 'result') {
                                terminalAppend(data.ok ? 'Done.\n' : 'Error: ' + (data.error || '') + '\n');
                                progress.classList.remove('visible');
                                barFill.style.width = '0%';
                                btn.disabled = false;
                                result.classList.add('visible');
                                if (data.ok) {
                                    result.classList.add('success');
                                    resultMsg.textContent = 'Scan complete. PDF report generated.';
                                    var summary = data.summary || {};
                                    var sev = summary.severity || {};
                                    resultMeta.textContent = 'Directories: ' + (summary.directory_count || 0) + ' | Admin: ' + (summary.admin_pages_count || 0) + ' | Ports: ' + (summary.ports_count || 0) + ' | SQL: ' + (summary.sql_vulns || 0) + ' | XSS: ' + (summary.xss_count || 0) + ' | CVEs: ' + (summary.cve_count || 0) + (sev.critical || sev.high ? ' | Severity: C' + (sev.critical || 0) + ' H' + (sev.high || 0) + ' M' + (sev.medium || 0) + ' L' + (sev.low || 0) : '');
                                    reportLink.href = 'reports/' + (data.report_filename || '');
                                    reportLink.style.display = 'inline-flex';
                                    lastScanResult = data;
                                    exportButtons.style.display = 'flex';
                                    loadHistory();
                                } else {
                                    result.classList.add('error');
                                    resultMsg.textContent = data.error || 'Scan or report failed.';
                                    reportLink.style.display = 'none';
                                }
                                return true;
                            }
                        } catch (e) {}
                        return false;
                    }
                    function read() {
                        return reader.read().then(function (chunk) {
                            if (chunk.done) {
                                if (buffer.length && processLine(buffer)) return;
                                return;
                            }
                            buffer += decoder.decode(chunk.value, { stream: true });
                            var lines = buffer.split('\n');
                            buffer = lines.pop() || '';
                            for (var i = 0; i < lines.length; i++) {
                                if (processLine(lines[i])) {
                                    reader.cancel();
                                    return;
                                }
                            }
                            return read();
                        });
                    }
                    return read();
                })
                .then(function () {
                    progress.classList.remove('visible');
                    btn.disabled = false;
                })
                .catch(function (err) {
                    progress.classList.remove('visible');
                    btn.disabled = false;
                    result.classList.add('visible', 'error');
                    resultMsg.textContent = 'Request failed: ' + (err.message || 'Network error');
                });
            }

            document.getElementById('btn-export-json').addEventListener('click', function () {
                if (!lastScanResult) return;
                var blob = new Blob([JSON.stringify(lastScanResult, null, 2)], { type: 'application/json' });
                var a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'scan_result_' + (lastScanResult.report_filename || 'export').replace(/\.pdf$/, '') + '.json';
                a.click();
                URL.revokeObjectURL(a.href);
            });
            document.getElementById('btn-export-csv').addEventListener('click', function () {
                if (!lastScanResult) return;
                var s = lastScanResult.summary || {};
                var sev = s.severity || {};
                var rows = [
                    ['Metric', 'Value'],
                    ['directory_count', s.directory_count || 0],
                    ['admin_pages_count', s.admin_pages_count || 0],
                    ['ports_count', s.ports_count || 0],
                    ['sql_vulns', s.sql_vulns || 0],
                    ['xss_count', s.xss_count || 0],
                    ['cve_count', s.cve_count || 0],
                    ['severity_critical', sev.critical || 0],
                    ['severity_high', sev.high || 0],
                    ['severity_medium', sev.medium || 0],
                    ['severity_low', sev.low || 0],
                ];
                var csv = rows.map(function (r) { return r.join(','); }).join('\n');
                var blob = new Blob([csv], { type: 'text/csv' });
                var a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'scan_summary.csv';
                a.click();
                URL.revokeObjectURL(a.href);
            });
        })();
    </script>
</body>
</html>
